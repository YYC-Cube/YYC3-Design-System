// path: jest.config.js
/**
 * YYC\u00b3 Design System \u2014 Jest Configuration
 *
 * Preset: ts-jest | Env: jsdom
 * Coverage threshold: 80% (branches/functions/lines/statements)
 */

/** @type {import('jest').Config} */
module.exports = {
  preset: "ts-jest",
  testEnvironment: "jsdom",
  roots: ["<rootDir>/src"],

  testMatch: [
    "**/__tests__/**/*.{ts,tsx}",
    "**/*.test.{ts,tsx}",
    "**/*.spec.{ts,tsx}",
  ],

  testPathIgnorePatterns: ["/node_modules/", "/src/qa/tests/e2e/"],

  transform: {
    "^.+\\.tsx?$": ["ts-jest", { tsconfig: "tsconfig.json" }],
  },

  moduleNameMapper: {
    "\\.(css|less|scss|sass)$": "identity-obj-proxy",
    "\\.(jpg|jpeg|png|gif|svg)$": "<rootDir>/src/qa/tests/__mocks__/fileMock.ts",
    "^@/(.*)$": "<rootDir>/src/$1",
  },

  setupFilesAfterSetup: ["<rootDir>/src/qa/tests/setup.ts"],

  collectCoverageFrom: [
    "src/app/**/*.{ts,tsx}",
    "!src/app/**/*.d.ts",
    "!src/app/**/index.ts",
    "!src/app/App.tsx",
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
  coverageReporters: ["text", "text-summary", "lcov", "html"],
  coverageDirectory: "coverage",

  maxWorkers: "50%",
  cacheDirectory: "<rootDir>/.jest-cache",
};
