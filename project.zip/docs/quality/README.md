# YYC³ Design System — Quality Assurance Guide

## Overview

This document describes the complete QA pipeline for the YYC³ Design System, covering type safety, testing, performance benchmarks, visual regression, CI/CD, and code style enforcement.

All QA configurations live in `src/qa/`. Test files are organized by type under `src/qa/tests/`.

## QA Pipeline Overview

```mermaid
graph TD
    A[Developer Push / PR] --> B{CI Pipeline}
    B --> C1[Stage 1: Quality]
    C1 --> C1a[TypeScript Check]
    C1 --> C1b[ESLint]
    C1 --> C1c[Prettier Check]
    C1 --> C1d[Locale Validation]
    
    C1 --> C2[Stage 2: Tests]
    C2 --> C2a[Unit Tests - Jest]
    C2 --> C2b[Integration Tests]
    C2 --> C2c[A11y Tests - jest-axe]
    C2 --> C2d[Coverage >= 80%]
    
    C1 --> C3[Stage 3: Build]
    C3 --> C3a[Vite Build]
    C3 --> C3b[Token Build]
    C3 --> C3c["Bundle Budget (JS<=200KB)"]
    
    C3 --> C4[Stage 4: E2E]
    C4 --> C4a[Playwright - Chromium]
    C4 --> C4b[Theme Switching]
    C4 --> C4c[Language Switching]
    C4 --> C4d[Token Manager]
    C4 --> C4e[Build Settings]
    C4 --> C4f[Storybook Isolation]
    C4 --> C4g[Performance Metrics]
    
    C3 --> C5[Stage 5: Performance]
    C5 --> C5a["Lighthouse CI (FCP<=1.5s)"]
    C5 --> C5b["A11y Score >= 90"]
    
    C1 --> C6[Stage 6: Visual - PRs only]
    C6 --> C6a[Chromatic - 7 modes]
    
    C2 & C3 & C4 & C5 --> C7[Stage 7: Deploy]
    C7 --> C7a[Production - main only]
    
    style C1 fill:#4ade80,stroke:#16a34a
    style C2 fill:#60a5fa,stroke:#2563eb
    style C3 fill:#fbbf24,stroke:#d97706
    style C4 fill:#a78bfa,stroke:#7c3aed
    style C5 fill:#f87171,stroke:#dc2626
    style C6 fill:#fb923c,stroke:#ea580c
    style C7 fill:#34d399,stroke:#059669
```

---

## Quick Start

```bash
# Install all QA dependencies
pnpm add -D jest ts-jest @jest/types jest-environment-jsdom identity-obj-proxy \
  @testing-library/react @testing-library/jest-dom @testing-library/user-event \
  jest-axe @types/jest-axe jest-junit \
  @playwright/test \
  eslint @typescript-eslint/eslint-plugin @typescript-eslint/parser \
  eslint-plugin-react-hooks eslint-plugin-jsx-a11y \
  prettier prettier-plugin-tailwindcss \
  husky lint-staged \
  @lhci/cli chromatic

# Initialize Playwright browsers
npx playwright install --with-deps chromium

# Initialize Husky
npx husky init
```

---

## Test Categories

### 1. Unit Tests (`src/qa/tests/unit/`)

| File | Covers | Cases |
|------|--------|-------|
| `Button.test.tsx` | Rendering, variants, sizes, click, disabled, focus, a11y | 12 |
| `ThemeContext.test.tsx` | Style switching, mode toggle, cycling, persistence, Ctrl+Alt+T | 7 |
| `LanguageContext.test.tsx` | Key-based t(), inline t(), toggle, persistence, Ctrl+Alt+L | 8 |
| `Animated.test.tsx` | Animation variants, duration/easing tokens, delay, repeat, animationend, fake timers | 15 |
| `LocaleValidation.test.ts` | Key diff detection, report formatting, assertion | 5 |

**Run:** `pnpm test -- --testPathPattern=unit`

### 2. Integration Tests (`src/qa/tests/integration/`)

| File | Covers | Cases |
|------|--------|-------|
| `TokenPlayground.test.tsx` | Tab switching, AI schemes, CSS export, reset, live preview | 10 |
| `TokenManager.test.tsx` | Tab navigation, file import, JSON editor, history, shortcuts | 8 |
| `BuildSettings.test.tsx` | Platform cards, toggles, dropdowns, generate, Ctrl+Alt+B | 6 |
| `StorybookIsolation.test.tsx` | Panel, switch, dropdown, slider, test run | 7 |

**Run:** `pnpm test -- --testPathPattern=integration`

### 3. Accessibility Tests (`src/qa/tests/a11y/`)

Uses **jest-axe** to audit all interactive components for WCAG AA compliance:
- Color contrast >= 4.5:1
- ARIA attributes present
- Keyboard navigation
- Form labels

**Run:** `pnpm test:a11y`

### 4. E2E Tests (`src/qa/tests/e2e/`)

Uses **Playwright** across Chromium, Firefox, WebKit, and Mobile Chrome:

| File | Covers |
|------|--------|
| `theme-switching.spec.ts` | Default theme, cycling, Ctrl+Alt+T, persistence, color changes |
| `language-switching.spec.ts` | Default lang, toggle, Ctrl+Alt+L, persistence, nav labels |
| `token-manager.spec.ts` | Tab switching, file import, export formats, Ctrl+Alt+I |
| `build-settings.spec.ts` | Platform cards, toggles, generate, Ctrl+Alt+B |
| `storybook-isolation.spec.ts` | Settings panel, isolation switch, layout dropdown, slider, test run |
| `performance-lhci.spec.ts` | Load time, CLS, CSS variables, theme switch perf, resource budget |

**Run:** `pnpm test:e2e`

### 5. Performance Benchmarks (`src/qa/tests/performance/`)

Uses **Lighthouse CI** with these thresholds:

| Metric | Budget | Five-High |
|--------|--------|-----------|
| FCP | <= 1.5s | High Performance |
| LCP | <= 2.5s | High Performance |
| CLS | <= 0.1 | High Consistency |
| TBT | <= 300ms | High Performance |
| JS Bundle | <= 200KB | High Performance |
| Total Assets | <= 500KB | High Performance |
| Accessibility Score | >= 90 | High Accessibility |

### 6. Visual Regression (`src/qa/tests/visual/`)

Uses **Chromatic** to capture 7 viewport/theme combinations per story:
- `future-light`, `future-dark`
- `cyber-light`, `cyber-dark`
- `business-light`, `business-dark`
- `mobile` (375x812)

---

## CI/CD Pipeline

**File:** `src/qa/ci-workflow.ts`

7-stage GitHub Actions workflow:

```
quality ──┬── test ──────┬── deploy
          │              │
          ├── build ─────┤
          │   │          │
          │   ├── e2e ───┘
          │   │
          │   └── performance
          │
          └── visual (PRs only)
```

| Stage | Checks | Blocks PR |
|-------|--------|-----------|
| 1. Quality | TypeScript, ESLint, Prettier, Locale Validation | Yes |
| 2. Tests | Jest (unit + integration + a11y), coverage >= 80% | Yes |
| 3. Build | Vite build, token build, bundle size budget | Yes |
| 4. E2E | Playwright (Chromium) | Yes |
| 5. Performance | Lighthouse CI thresholds | Yes |
| 6. Visual | Chromatic screenshot diff | Yes (on PR) |
| 7. Deploy | Production deployment | Auto (on main) |

---

## Locale Validation

**File:** `src/qa/locale-validation.ts`

Automatically detects key mismatches between `zh.json` and `en.json`:

```bash
pnpm validate:locales
```

Output:
```
═══════════════════════════════════════════════
  YYC³ Locale Validation Report
  2026-02-26T00:00:00.000Z
═══════════════════════════════════════════════

  Namespaces checked: 14
  Total keys:         350+
  Status:             VALID

  All locale keys are in sync. No issues found.
═══════════════════════════════════════════════
```

---

## Code Quality Enforcement

### ESLint (`src/qa/eslint.config.ts`)
- `@typescript-eslint` — type-aware linting
- `react-hooks` — hooks rules
- `jsx-a11y` — accessibility rules

### Prettier (`src/qa/prettier.config.ts`)
- `prettier-plugin-tailwindcss` — automatic class sorting

### Husky + lint-staged (`src/qa/husky.config.ts`)
Pre-commit hook runs:
1. `tsc --noEmit` — type check
2. `eslint --fix` — auto-fix lint issues
3. `prettier --write` — format staged files
4. Locale validation — ensure zh/en sync

Commit message enforces conventional commits:
```
feat(token-manager): add batch copy functionality
fix(theme): resolve dark mode contrast issue
docs(qa): update test coverage thresholds
```

---

## Type Definitions

All types are in `src/types/`:

| File | Covers |
|------|--------|
| `tokens.d.ts` | DesignTokens, ColorTokens, SpacingTokens, etc. |
| `theme.d.ts` | ThemeMode, VisualTheme, ThemeContextValue |
| `language.d.ts` | Locale, TFunction, LocaleNamespaces |
| `components.d.ts` | ButtonProps, InputProps, CardProps, etc. (26+) |
| `animation.d.ts` | AnimationConfig, AnimationPresets, DurationKey |
| `index.d.ts` | Unified re-export of all types |

Locale types with IDE autocomplete: `src/locales/index.ts`

---

## Design Tokens

**Source:** `design/tokens.json` (validated by `design/tokens-schema.json`)

Contains all 3 themes (future/cyber/business) x 2 modes (light/dark) = 6 color palettes, plus shared spacing, radius, shadow, animation, icon, and typography tokens. All colors include OKLCH + HEX fallback.

**Validation:**
```bash
npx ts-node src/qa/scripts/validate-tokens.ts
```

---

## Scripts

| Script | File | Purpose |
|--------|------|---------|
| `verify-types` | `src/qa/scripts/verify-types.ts` | `tsc --noEmit` + verify type definition files exist |
| `validate-tokens` | `src/qa/scripts/validate-tokens.ts` | Validate `design/tokens.json` against schema |
| `perf-test` | `src/qa/scripts/perf-test.ts` | Build + preview + Lighthouse CI automated runner |

---

## Root-Level Config Templates

Ready-to-copy configuration files in `src/qa/configs/`:

| Template | Copy To | Purpose |
|----------|---------|---------|
| `eslintrc.js` | `.eslintrc.js` | ESLint rules (TS, React hooks, jsx-a11y, Prettier) |
| `prettierrc.json` | `.prettierrc` | Prettier config (Tailwind plugin) |
| `jest.config.js` | `jest.config.js` | Jest with ts-jest, coverage thresholds 80% |
| `playwright.config.ts` | `playwright.config.ts` | Playwright E2E (4 browsers) |
| `lintstagedrc.json` | `.lintstagedrc.json` | lint-staged rules for pre-commit |
| `lighthouserc.json` | `lighthouserc.json` | Lighthouse CI performance budgets |
| `chromatic.config.json` | `.chromatic.config.json` | Chromatic visual regression |

---

## GitHub Actions Workflows

Template YAML strings in `src/qa/workflows/ci.yml.ts`:

| Export | Target File | Stages |
|--------|-------------|--------|
| `ciYml` | `.github/workflows/ci.yml` | quality \u2192 test \u2192 build \u2192 e2e \u2192 perf \u2192 visual \u2192 deploy |
| `labelPrYml` | `.github/workflows/label-pr.yml` | Auto-label PRs |
| `deployYml` | `.github/workflows/deploy.yml` | GitHub Pages deployment |

---

## Local Commands Reference

```bash
# Type check
pnpm exec tsc --noEmit

# Lint
pnpm lint
pnpm lint:fix

# Format
pnpm format
pnpm format:check

# Unit + Integration tests
pnpm test
pnpm test -- --coverage

# Accessibility tests
pnpm test:a11y

# E2E tests
pnpm test:e2e
pnpm test:e2e -- --project=chromium

# Locale validation
pnpm validate:locales

# Token validation
npx ts-node src/qa/scripts/validate-tokens.ts

# Performance
npx ts-node src/qa/scripts/perf-test.ts

# Visual regression
pnpm chromatic

# Full QA suite
pnpm qa
```

---

## Troubleshooting

### Tests fail with "Cannot find module"
Ensure `moduleNameMapper` in `jest.config.ts` maps CSS and static files correctly.

### Locale validation fails
Run `pnpm validate:locales` to see which keys are missing. Add the missing keys to the appropriate locale file.

### Lighthouse score too low
1. Check bundle size: `du -sh dist/assets/*.js`
2. Verify CSS Custom Properties are used (no runtime color computation)
3. Ensure images have explicit width/height

### Chromatic shows unexpected changes
1. Check if CSS variables changed between themes
2. Ensure animations are paused (`pauseAnimationAtEnd: true` in config)
3. Use `delay: 300` to wait for transitions to settle

### ESLint conflicts with Prettier
Ensure `eslint-config-prettier` is the last extends entry. The Prettier plugin handles all formatting.

### jest-axe reports "color contrast" violations
1. Check `design/tokens.json` \u2014 verify `foreground` and `background` HEX values have contrast >= 4.5:1
2. Use [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/) to validate
3. Ensure the test wrapper provides `ThemeProvider` + `LanguageProvider`

### Token validation fails
Run `npx ts-node src/qa/scripts/validate-tokens.ts` to see which fields are missing. Compare against `design/tokens-schema.json`.

### How to view Chromatic screenshots in PR
1. Chromatic bot comments on the PR with a link to the build
2. Click "View Changes" to see side-by-side screenshot diffs
3. Approve or reject visual changes in the Chromatic UI

### How to view Lighthouse report
1. In CI, Lighthouse uploads to temporary public storage
2. The report URL is printed in the GitHub Actions log
3. Locally: `npx lhci autorun` generates `lighthouse-report.json`

### How to view Codecov badge
Add to README: `![Coverage](https://codecov.io/gh/<org>/<repo>/branch/main/graph/badge.svg)`

---

## Coverage Goals

| Metric | Current | Target |
|--------|---------|--------|
| Line Coverage | — | >= 80% |
| Branch Coverage | — | >= 70% |
| Function Coverage | — | >= 75% |
| A11y Violations | 0 | 0 |
| Bundle Size (JS) | — | <= 200KB |
| FCP | — | <= 1.5s |
| Locale Sync | 100% | 100% |

---

*YYC³ Design System v1.0.0 — Five-High / Five-Standard / Five-Implementation*