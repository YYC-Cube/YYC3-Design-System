/**
 * YYC³ Design System — Husky + lint-staged Configuration
 *
 * Enforces code quality checks before every git commit.
 *
 * Setup:
 *   1. pnpm add -D husky lint-staged
 *   2. npx husky init
 *   3. Copy the pre-commit hook content to .husky/pre-commit
 *
 * Five-High Alignment:
 *   - High Consistency: prevents non-compliant code from entering the repo
 *   - High Performance: only checks staged files (fast)
 */

/**
 * lint-staged configuration (add to package.json)
 */
export const lintStagedConfig = {
  // TypeScript/JavaScript files
  "*.{ts,tsx}": [
    "eslint --fix --max-warnings 0",
    "prettier --write",
  ],

  // CSS files
  "*.css": [
    "prettier --write",
  ],

  // JSON files (including locale files)
  "*.json": [
    "prettier --write",
  ],

  // Locale files — run locale validation
  "src/locales/*.json": [
    "ts-node -e \"const { assertLocalesValid } = require('./src/qa/locale-validation'); assertLocalesValid();\"",
  ],
};

/**
 * Husky pre-commit hook content
 * Save as: .husky/pre-commit
 */
export const preCommitHook = `#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

# Run typecheck
echo "🔍 Running type check..."
pnpm exec tsc --noEmit || {
  echo "❌ TypeScript check failed. Please fix type errors before committing."
  exit 1
}

# Run lint-staged
echo "🧹 Running lint-staged..."
pnpm exec lint-staged || {
  echo "❌ Lint-staged failed. Please fix linting errors before committing."
  exit 1
}

# Run locale validation
echo "🌐 Validating locale files..."
pnpm exec ts-node -e "
  const { assertLocalesValid } = require('./src/qa/locale-validation');
  assertLocalesValid();
  console.log('✅ Locale files are in sync.');
" || {
  echo "❌ Locale validation failed. zh.json and en.json have mismatched keys."
  exit 1
}

echo "✅ All pre-commit checks passed!"
`;

/**
 * Husky commit-msg hook for conventional commits
 * Save as: .husky/commit-msg
 */
export const commitMsgHook = `#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

# Validate conventional commit format
commit_msg=$(cat "$1")
pattern="^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\\(.+\\))?: .{1,72}"

if ! echo "$commit_msg" | grep -qE "$pattern"; then
  echo "❌ Invalid commit message format."
  echo "   Expected: <type>(<scope>): <description>"
  echo "   Types: feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert"
  echo "   Example: feat(token-manager): add batch copy functionality"
  exit 1
fi
`;

/**
 * Package.json scripts to add
 */
export const packageScripts = {
  "prepare": "husky",
  "lint": "eslint src/ --max-warnings 0",
  "lint:fix": "eslint src/ --fix",
  "typecheck": "tsc --noEmit",
  "format": "prettier --write 'src/**/*.{ts,tsx,css,json}'",
  "format:check": "prettier --check 'src/**/*.{ts,tsx,css,json}'",
  "test": "jest --passWithNoTests",
  "test:watch": "jest --watch",
  "test:coverage": "jest --coverage",
  "test:a11y": "jest --testPathPattern=a11y",
  "test:e2e": "playwright test",
  "test:e2e:ui": "playwright test --ui",
  "validate:locales": "ts-node -e \"const { formatReport, validateLocales } = require('./src/qa/locale-validation'); console.log(formatReport(validateLocales()));\"",
  "build:tokens": "node build-tokens.mjs",
  "qa": "pnpm typecheck && pnpm lint && pnpm test -- --coverage && pnpm format:check",
  "qa:fix": "pnpm lint:fix && pnpm format",
  "chromatic": "chromatic --project-token=$CHROMATIC_PROJECT_TOKEN",
};
