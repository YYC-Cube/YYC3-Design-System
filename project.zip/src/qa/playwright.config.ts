/**
 * YYC³ Design System — Playwright E2E Configuration
 *
 * Install:
 *   pnpm add -D @playwright/test
 *   npx playwright install
 *
 * Run:
 *   npx playwright test
 *   npx playwright test --headed    # with browser UI
 *   npx playwright show-report      # view HTML report
 */

export const playwrightConfig = {
  testDir: "./src/qa/tests/e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ["html", { open: "never" }],
    ["junit", { outputFile: "test-results/e2e-results.xml" }],
  ],
  use: {
    baseURL: "http://localhost:5173",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: { browserName: "chromium" as const },
    },
    {
      name: "firefox",
      use: { browserName: "firefox" as const },
    },
    {
      name: "webkit",
      use: { browserName: "webkit" as const },
    },
    {
      name: "mobile-chrome",
      use: {
        browserName: "chromium" as const,
        viewport: { width: 375, height: 812 },
        isMobile: true,
      },
    },
  ],
  webServer: {
    command: "pnpm dev",
    port: 5173,
    reuseExistingServer: !process.env.CI,
  },
};

export default playwrightConfig;
