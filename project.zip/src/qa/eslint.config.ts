/**
 * YYC³ Design System — ESLint Configuration (Reference Template)
 *
 * This file serves as the recommended ESLint configuration for the project.
 * To use in production:
 *   1. Install: pnpm add -D eslint @typescript-eslint/eslint-plugin @typescript-eslint/parser eslint-plugin-react-hooks eslint-plugin-jsx-a11y
 *   2. Copy this file to the project root as `eslint.config.ts`
 *   3. Run: npx eslint src/ --fix
 *
 * Five-High Alignment:
 *   - High Accessibility: jsx-a11y plugin enforces ARIA, contrast, keyboard navigation
 *   - High Consistency: unified import ordering, naming conventions
 *   - High Performance: warns on inefficient patterns (e.g., inline objects in JSX)
 */

export const eslintConfig = {
  root: true,
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaVersion: 2024,
    sourceType: "module",
    ecmaFeatures: { jsx: true },
    project: "./tsconfig.json",
  },
  plugins: [
    "@typescript-eslint",
    "react-hooks",
    "jsx-a11y",
  ],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:react-hooks/recommended",
    "plugin:jsx-a11y/recommended",
  ],
  rules: {
    // ─── TypeScript ───
    "@typescript-eslint/no-unused-vars": ["warn", { argsIgnorePattern: "^_" }],
    "@typescript-eslint/no-explicit-any": "warn",
    "@typescript-eslint/consistent-type-imports": ["error", { prefer: "type-imports" }],

    // ─── React Hooks ───
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn",

    // ─── Accessibility (Five-High: 高可访问性) ───
    "jsx-a11y/alt-text": "error",
    "jsx-a11y/aria-props": "error",
    "jsx-a11y/aria-role": "error",
    "jsx-a11y/click-events-have-key-events": "warn",
    "jsx-a11y/no-noninteractive-element-interactions": "warn",
    "jsx-a11y/label-has-associated-control": "warn",

    // ─── Code Quality ───
    "no-console": ["warn", { allow: ["warn", "error"] }],
    "no-debugger": "error",
    "prefer-const": "error",
    "no-var": "error",
    "eqeqeq": ["error", "always"],

    // ─── Import Ordering (Five-High: 高一致性) ───
    "sort-imports": ["warn", { ignoreDeclarationSort: true }],
  },
  settings: {
    react: { version: "detect" },
  },
  ignorePatterns: [
    "dist/",
    "node_modules/",
    "*.config.*",
    "*.d.ts",
  ],
};

export default eslintConfig;
