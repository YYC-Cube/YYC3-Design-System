/**
 * YYC³ Design System — Jest Configuration
 *
 * Covers: unit tests, integration tests, accessibility tests
 * Frameworks: Jest + React Testing Library + jest-axe
 *
 * Install:
 *   pnpm add -D jest @jest/types ts-jest @testing-library/react @testing-library/jest-dom
 *   pnpm add -D @testing-library/user-event jest-axe @types/jest-axe jest-environment-jsdom
 *   pnpm add -D identity-obj-proxy
 */

import type { Config } from "@jest/types";

const config: Config.InitialOptions = {
  // ─── Environment ───
  testEnvironment: "jsdom",
  roots: ["<rootDir>/src"],

  // ─── File patterns ───
  testMatch: [
    "**/__tests__/**/*.{ts,tsx}",
    "**/*.test.{ts,tsx}",
    "**/*.spec.{ts,tsx}",
  ],

  // ─── Transform ───
  transform: {
    "^.+\\.tsx?$": ["ts-jest", { tsconfig: "tsconfig.json" }],
  },

  // ─── Module resolution ───
  moduleNameMapper: {
    // Handle CSS modules
    "\\.(css|less|scss|sass)$": "identity-obj-proxy",
    // Handle static assets
    "\\.(jpg|jpeg|png|gif|svg)$": "<rootDir>/src/qa/tests/__mocks__/fileMock.ts",
    // Path aliases
    "^@/(.*)$": "<rootDir>/src/$1",
    "^../../locales/(.*)$": "<rootDir>/src/locales/$1",
  },

  // ─── Setup ───
  setupFilesAfterSetup: ["<rootDir>/src/qa/tests/setup.ts"],

  // ─── Coverage ───
  collectCoverageFrom: [
    "src/app/**/*.{ts,tsx}",
    "!src/app/**/*.d.ts",
    "!src/app/**/index.ts",
    "!src/app/App.tsx",
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 75,
      lines: 80,
      statements: 80,
    },
  },
  coverageReporters: ["text", "text-summary", "lcov", "html"],
  coverageDirectory: "coverage",

  // ─── Performance ───
  maxWorkers: "50%",
  cacheDirectory: "<rootDir>/.jest-cache",
};

export default config;