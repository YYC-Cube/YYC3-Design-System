// path: jest.config.js (copy to project root)
/**
 * YYC\u00b3 Design System \u2014 Jest Configuration (Root-level)
 *
 * Install:
 *   pnpm add -D jest ts-jest @jest/types jest-environment-jsdom identity-obj-proxy
 *   pnpm add -D @testing-library/react @testing-library/jest-dom @testing-library/user-event
 *   pnpm add -D jest-axe @types/jest-axe jest-junit
 */

/** @type {import('jest').Config} */
module.exports = {
  // Environment
  preset: "ts-jest",
  testEnvironment: "jsdom",
  roots: ["<rootDir>/src"],

  // File patterns
  testMatch: [
    "**/__tests__/**/*.{ts,tsx}",
    "**/*.test.{ts,tsx}",
    "**/*.spec.{ts,tsx}",
  ],

  // Ignore E2E tests (handled by Playwright)
  testPathIgnorePatterns: ["/node_modules/", "/src/qa/tests/e2e/"],

  // Transform
  transform: {
    "^.+\\.tsx?$": ["ts-jest", { tsconfig: "tsconfig.json" }],
  },

  // Module resolution
  moduleNameMapper: {
    // CSS modules / styles
    "\\.(css|less|scss|sass)$": "identity-obj-proxy",
    // Static assets
    "\\.(jpg|jpeg|png|gif|svg)$": "<rootDir>/src/qa/tests/__mocks__/fileMock.ts",
    // Path aliases
    "^@/(.*)$": "<rootDir>/src/$1",
  },

  // Setup
  setupFilesAfterSetup: ["<rootDir>/src/qa/tests/setup.ts"],

  // Coverage
  collectCoverageFrom: [
    "src/app/**/*.{ts,tsx}",
    "!src/app/**/*.d.ts",
    "!src/app/**/index.ts",
    "!src/app/App.tsx",
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
  coverageReporters: ["text", "text-summary", "lcov", "html"],
  coverageDirectory: "coverage",

  // Performance
  maxWorkers: "50%",
  cacheDirectory: "<rootDir>/.jest-cache",
};
