/**
 * YYC³ Design System — Prettier Configuration (Reference Template)
 *
 * To use in production:
 *   1. Install: pnpm add -D prettier
 *   2. Copy this export to `.prettierrc` (as JSON) at project root
 *   3. Run: npx prettier --write src/
 *
 * Five-High Alignment:
 *   - High Consistency: enforces uniform code style across all files
 *   - High Performance: consistent formatting reduces diff noise in PRs
 */

export const prettierConfig = {
  semi: true,
  singleQuote: false,
  trailingComma: "es5" as const,
  tabWidth: 2,
  useTabs: false,
  printWidth: 100,
  bracketSpacing: true,
  bracketSameLine: false,
  arrowParens: "always" as const,
  endOfLine: "lf" as const,

  // Tailwind CSS class sorting (requires prettier-plugin-tailwindcss)
  plugins: ["prettier-plugin-tailwindcss"],
  tailwindFunctions: ["clsx", "cn", "cva"],

  overrides: [
    {
      files: "*.json",
      options: { tabWidth: 2, printWidth: 80 },
    },
    {
      files: "*.css",
      options: { singleQuote: false },
    },
  ],
};

export default prettierConfig;
