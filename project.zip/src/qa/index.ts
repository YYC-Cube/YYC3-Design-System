/**
 * YYC\u00b3 Design System \u2014 Quality Assurance Module (Unified Exports)
 *
 * File Structure:
 *   src/qa/
 *   \u251c\u2500\u2500 index.ts                    \u2190 This file
 *   \u251c\u2500\u2500 eslint.config.ts            \u2190 ESLint configuration
 *   \u251c\u2500\u2500 prettier.config.ts          \u2190 Prettier configuration
 *   \u251c\u2500\u2500 jest.config.ts              \u2190 Jest test runner config
 *   \u251c\u2500\u2500 playwright.config.ts        \u2190 Playwright E2E config
 *   \u251c\u2500\u2500 husky.config.ts             \u2190 Git hooks + lint-staged
 *   \u251c\u2500\u2500 ci-workflow.ts              \u2190 GitHub Actions CI/CD pipeline
 *   \u251c\u2500\u2500 locale-validation.ts        \u2190 zh/en key diff detector
 *   \u251c\u2500\u2500 scripts/
 *   \u2502   \u251c\u2500\u2500 verify-types.ts         \u2190 tsc --noEmit CI script
 *   \u2502   \u251c\u2500\u2500 validate-tokens.ts      \u2190 tokens.json schema validation
 *   \u2502   \u2514\u2500\u2500 perf-test.ts            \u2190 Lighthouse CI runner
 *   \u251c\u2500\u2500 configs/                    \u2190 Root-level config templates
 *   \u2502   \u251c\u2500\u2500 eslintrc.js             \u2190 Copy to .eslintrc.js
 *   \u2502   \u251c\u2500\u2500 prettierrc.json         \u2190 Copy to .prettierrc
 *   \u2502   \u251c\u2500\u2500 jest.config.js          \u2190 Copy to jest.config.js
 *   \u2502   \u251c\u2500\u2500 playwright.config.ts    \u2190 Copy to playwright.config.ts
 *   \u2502   \u251c\u2500\u2500 lintstagedrc.json       \u2190 Copy to .lintstagedrc.json
 *   \u2502   \u251c\u2500\u2500 lighthouserc.json       \u2190 Copy to lighthouserc.json
 *   \u2502   \u2514\u2500\u2500 chromatic.config.json   \u2190 Copy to .chromatic.config.json
 *   \u251c\u2500\u2500 workflows/
 *   \u2502   \u2514\u2500\u2500 ci.yml.ts               \u2190 GitHub Actions YAML templates
 *   \u2514\u2500\u2500 tests/
 *       \u251c\u2500\u2500 setup.ts                \u2190 Jest global setup
 *       \u251c\u2500\u2500 __mocks__/fileMock.ts   \u2190 Static file mock
 *       \u251c\u2500\u2500 unit/
 *       \u2502   \u251c\u2500\u2500 Button.test.tsx
 *       \u2502   \u251c\u2500\u2500 ThemeContext.test.tsx
 *       \u2502   \u251c\u2500\u2500 LanguageContext.test.tsx
 *       \u2502   \u251c\u2500\u2500 Animated.test.tsx
 *       \u2502   \u2514\u2500\u2500 LocaleValidation.test.ts
 *       \u251c\u2500\u2500 integration/
 *       \u2502   \u251c\u2500\u2500 TokenPlayground.test.tsx
 *       \u2502   \u251c\u2500\u2500 TokenManager.test.tsx
 *       \u2502   \u251c\u2500\u2500 BuildSettings.test.tsx
 *       \u2502   \u2514\u2500\u2500 StorybookIsolation.test.tsx
 *       \u251c\u2500\u2500 e2e/
 *       \u2502   \u251c\u2500\u2500 theme-switching.spec.ts
 *       \u2502   \u251c\u2500\u2500 language-switching.spec.ts
 *       \u2502   \u251c\u2500\u2500 token-manager.spec.ts
 *       \u2502   \u251c\u2500\u2500 build-settings.spec.ts
 *       \u2502   \u251c\u2500\u2500 storybook-isolation.spec.ts
 *       \u2502   \u2514\u2500\u2500 performance-lhci.spec.ts
 *       \u251c\u2500\u2500 a11y/
 *       \u2502   \u2514\u2500\u2500 accessibility.test.tsx
 *       \u251c\u2500\u2500 performance/
 *       \u2502   \u2514\u2500\u2500 lighthouse.config.ts
 *       \u2514\u2500\u2500 visual/
 *           \u251c\u2500\u2500 chromatic.config.ts
 *           \u2514\u2500\u2500 Card.visual.test.tsx
 *
 * Coverage:
 *   \u2705 Type definitions       \u2014 src/types/*.d.ts (6 files)
 *   \u2705 Unit tests              \u2014 5 test files, 50+ test cases
 *   \u2705 Integration tests       \u2014 4 test files, 35+ test cases
 *   \u2705 E2E tests               \u2014 6 spec files (Playwright)
 *   \u2705 Accessibility tests     \u2014 jest-axe audits for all components
 *   \u2705 Visual regression       \u2014 Chromatic + Card.visual.test.tsx (6 theme modes)
 *   \u2705 Performance benchmarks  \u2014 Lighthouse CI thresholds
 *   \u2705 CI/CD pipeline          \u2014 7-stage GitHub Actions workflow
 *   \u2705 Code quality            \u2014 ESLint + Prettier + Husky + lint-staged
 *   \u2705 Locale validation       \u2014 Automated zh/en key sync checker
 *   \u2705 Token validation        \u2014 JSON Schema + validate-tokens.ts
 *   \u2705 Root-level configs      \u2014 7 ready-to-copy config files
 *   \u2705 CI workflow templates   \u2014 ci.yml, label-pr.yml, deploy.yml
 *   \u2705 Scripts                 \u2014 verify-types.ts, validate-tokens.ts, perf-test.ts
 */

export { eslintConfig } from "./eslint.config";
export { prettierConfig } from "./prettier.config";
export { workflowYaml, packageScripts, devDependencies } from "./ci-workflow";
export { validateLocales, formatReport, assertLocalesValid } from "./locale-validation";
export type { LocaleValidationReport } from "./locale-validation";
export { lintStagedConfig, preCommitHook, commitMsgHook } from "./husky.config";
export { ciYml, labelPrYml, deployYml } from "./workflows/ci.yml";
