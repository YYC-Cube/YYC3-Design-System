/**
 * YYC³ Design System — Jest Test Setup
 *
 * This file runs before each test suite.
 * Configures: jest-dom matchers, axe-core, mocks for browser APIs.
 */

import "@testing-library/jest-dom";

// ─── Mock localStorage ───
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => { store[key] = value; },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; },
    get length() { return Object.keys(store).length; },
    key: (index: number) => Object.keys(store)[index] || null,
  };
})();
Object.defineProperty(window, "localStorage", { value: localStorageMock });

// ─── Mock matchMedia ───
Object.defineProperty(window, "matchMedia", {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
  }),
});

// ─── Mock getComputedStyle ───
const originalGetComputedStyle = window.getComputedStyle;
window.getComputedStyle = (elt: Element, pseudoElt?: string | null) => {
  const style = originalGetComputedStyle(elt, pseudoElt);
  return new Proxy(style, {
    get(target, prop) {
      if (prop === "getPropertyValue") {
        return (name: string) => {
          // Return mock CSS variable values for testing
          const mockVars: Record<string, string> = {
            "--primary": "#2563eb",
            "--primary-foreground": "#ffffff",
            "--background": "#ffffff",
            "--foreground": "#0f172a",
            "--radius": "0.5rem",
          };
          return mockVars[name] || target.getPropertyValue(name);
        };
      }
      return Reflect.get(target, prop);
    },
  });
};

// ─── Mock clipboard API ───
Object.assign(navigator, {
  clipboard: {
    writeText: jest.fn().mockResolvedValue(undefined),
    readText: jest.fn().mockResolvedValue(""),
  },
});

// ─── Suppress React 18 act warnings in tests ───
const originalError = console.error;
console.error = (...args: unknown[]) => {
  if (typeof args[0] === "string" && args[0].includes("act(")) return;
  originalError.call(console, ...args);
};
