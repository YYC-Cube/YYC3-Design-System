// Mock for static file imports (images, SVGs, etc.)
export default "test-file-stub";
