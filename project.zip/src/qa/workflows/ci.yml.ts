// path: src/qa/workflows/ci.yml.ts
/**
 * YYC\u00b3 Design System \u2014 GitHub Actions CI/CD Workflow
 *
 * Copy the exported YAML string to: .github/workflows/ci.yml
 *
 * Pipeline: quality \u2192 test \u2192 build \u2192 e2e \u2192 performance \u2192 visual \u2192 deploy
 */

export const ciYml = `name: YYC\u00b3 Design System CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  NODE_VERSION: '20'
  PNPM_VERSION: '9'

concurrency:
  group: ci-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  quality:
    name: "\u2705 Code Quality"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - name: TypeScript Check
        run: pnpm exec tsc --noEmit
      - name: ESLint
        run: pnpm lint
      - name: Prettier Check
        run: pnpm format:check
      - name: Locale Validation
        run: pnpm validate:locales

  test:
    name: "\uD83E\uDDEA Tests"
    runs-on: ubuntu-latest
    needs: quality
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - name: Unit + Integration Tests
        run: pnpm test -- --coverage --ci
      - name: Upload Coverage
        uses: actions/upload-artifact@v4
        with:
          name: coverage
          path: coverage/
          retention-days: 14
      - name: Coverage Check (\u2265 80%)
        run: |
          COVERAGE=\$(cat coverage/coverage-summary.json | jq '.total.lines.pct')
          echo "Line coverage: \${COVERAGE}%"
          if (( \$(echo "\$COVERAGE < 80" | bc -l) )); then
            echo "::error::Coverage \${COVERAGE}% below 80%"
            exit 1
          fi

  build:
    name: "\uD83D\uDCE6 Build"
    runs-on: ubuntu-latest
    needs: quality
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - name: Build
        run: pnpm build
      - name: Bundle Size Check
        run: |
          JS_SIZE=\$(du -sk dist/assets/*.js 2>/dev/null | awk '{sum+=\$1} END {print sum+0}')
          echo "JS: \${JS_SIZE}KB"
          if [ "\$JS_SIZE" -gt 200 ]; then
            echo "::error::JS bundle \${JS_SIZE}KB exceeds 200KB"
            exit 1
          fi
      - uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/
          retention-days: 7

  e2e:
    name: "\uD83C\uDF10 E2E Tests"
    runs-on: ubuntu-latest
    needs: build
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - name: Install Playwright
        run: npx playwright install --with-deps chromium
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/
      - name: Run E2E
        run: pnpm test:e2e --project=chromium
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: e2e-results
          path: playwright-report/
          retention-days: 14

  performance:
    name: "\u26A1 Performance"
    runs-on: ubuntu-latest
    needs: build
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/
      - name: Lighthouse CI
        run: |
          npx @lhci/cli autorun \\
            --collect.staticDistDir=dist \\
            --assert.assertions.categories:performance="error;minScore=0.85" \\
            --assert.assertions.categories:accessibility="error;minScore=0.90" \\
            --assert.assertions.first-contentful-paint="error;maxNumericValue=1500" \\
            --assert.assertions.largest-contentful-paint="error;maxNumericValue=2500"

  visual:
    name: "\uD83D\uDDBC Visual Regression"
    runs-on: ubuntu-latest
    needs: quality
    if: github.event_name == 'pull_request'
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: pnpm/action-setup@v4
        with:
          version: \${{ env.PNPM_VERSION }}
      - uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - name: Build Storybook
        run: pnpm build-storybook
      - name: Chromatic
        uses: chromaui/action@latest
        with:
          projectToken: \${{ secrets.CHROMATIC_PROJECT_TOKEN }}
          exitZeroOnChanges: false
          exitOnceUploaded: true

  deploy:
    name: "\uD83D\uDE80 Deploy"
    runs-on: ubuntu-latest
    needs: [test, build, e2e, performance]
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    steps:
      - uses: actions/checkout@v4
      - uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/
      - name: Deploy
        run: echo "Configure deployment target (Vercel/Netlify/GitHub Pages)"
`;

export const labelPrYml = `name: Label PR

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  label:
    runs-on: ubuntu-latest
    permissions:
      pull-requests: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/labeler@v5
        with:
          repo-token: \${{ secrets.GITHUB_TOKEN }}
`;

export const deployYml = `name: Deploy

on:
  workflow_run:
    workflows: ["YYC\u00b3 Design System CI/CD"]
    types: [completed]
    branches: [main]

jobs:
  deploy:
    if: \${{ github.event.workflow_run.conclusion == 'success' }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: '9'
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'
      - run: pnpm install --frozen-lockfile
      - run: pnpm build
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v4
        with:
          github_token: \${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
`;
