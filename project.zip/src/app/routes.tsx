import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { OverviewPage } from "./pages/OverviewPage";
import { ComponentsPage } from "./pages/ComponentsPage";
import { PlaygroundPage } from "./pages/PlaygroundPage";
import { TokensPage } from "./pages/TokensPage";
import { AlignmentPage } from "./pages/AlignmentPage";
import { TokenManagerPage } from "./pages/TokenManagerPage";
import { BuildSettingsPage } from "./pages/BuildSettingsPage";
import { QADashboardPage } from "./pages/QADashboardPage";
import { ThemeCustomizerPage } from "./pages/ThemeCustomizerPage";
import { RouteApiGuidePage } from "./pages/RouteApiGuidePage";
import { useLanguage } from "./context/LanguageContext";
import { LanguageProvider } from "./context/LanguageContext";
import { ThemeProvider } from "./context/ThemeContext";
import { PWAProvider } from "./components/PWAProvider";
import { Outlet } from "react-router";

function RootProviders() {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <PWAProvider>
          <Outlet />
        </PWAProvider>
      </ThemeProvider>
    </LanguageProvider>
  );
}

function NotFound() {
  const { t } = useLanguage();
  return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="text-center space-y-2">
        <h2 className="text-2xl">404</h2>
        <p className="text-muted-foreground">{t("notFound.message")}</p>
      </div>
    </div>
  );
}

export const router = createBrowserRouter([
  {
    Component: RootProviders,
    children: [
      {
        path: "/",
        Component: Layout,
        children: [
          { index: true, Component: OverviewPage },
          { path: "components", Component: ComponentsPage },
          { path: "playground", Component: PlaygroundPage },
          { path: "tokens", Component: TokensPage },
          { path: "alignment", Component: AlignmentPage },
          { path: "token-manager", Component: TokenManagerPage },
          { path: "build-settings", Component: BuildSettingsPage },
          { path: "qa", Component: QADashboardPage },
          { path: "system-settings", Component: ThemeCustomizerPage },
          { path: "route-guide", Component: RouteApiGuidePage },
          { path: "*", Component: NotFound },
        ],
      },
    ],
  },
]);