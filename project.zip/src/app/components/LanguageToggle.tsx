/**
 * YYC³ Design System — Language Toggle
 *
 * Token Reference:
 *   border:     var(--border)
 *   card:       var(--card)
 *   foreground: var(--foreground)
 *   muted:      var(--muted)  — hover state
 *   animation:  var(--duration-fast) var(--easing-default)
 */
import { Languages } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

export function LanguageToggle() {
  const { lang, toggleLang, t } = useLanguage();

  return (
    <button
      onClick={toggleLang}
      className="flex items-center justify-center gap-1.5 h-9 px-2.5 rounded-lg border border-border bg-card text-foreground hover:bg-muted transition-all"
      aria-label={lang === "zh" ? t("lang.switchToEn") : t("lang.switchToZh")}
      title={lang === "zh" ? "Switch to English (Ctrl+Alt+L)" : "Switch to \u4e2d\u6587 (Ctrl+Alt+L)"}
    >
      <Languages className="size-4" />
      <span className="text-xs">{lang === "zh" ? "\u4e2d" : "EN"}</span>
    </button>
  );
}