## 🎯 质量保障完整 Prompt

## 项目概览
我们已经完成了 YYC³ Design System 的核心功能：
- 三套视觉主题（Future‑Tech / Cyber‑Punk / Business） + Light/Dark 双模式，所有颜色采用 OKLCH + HEX 回退；
- 完整的中/英双语系统（LanguageContext + LanguageToggle，默认中文，Ctrl+Alt+L 快捷键）；
- 26+ UI 组件、Token Playground、令牌导出、Custom Token Manager、Storybook Isolation Mode、Multi‑Platform Build Settings 已实现并双语化。

现在需要 **一个完整的质量保障体系**，包括 **类型定义、单元测试、集成测试、端到端测试、可访问性测试、性能基准、视觉回归、CI/CD 工作流、代码风格检查以及发布脚本**。所有代码必须使用 **TypeScript**，测试框架统一为 **Jest + React Testing Library**（单元/集成），**Playwright**（E2E），可访问性使用 **jest‑axe**，性能基准使用 **lighthouse‑ci**，视觉回归使用 **Chromatic**。

### 任务目标
1. **类型定义**：为 Design Tokens、Theme、Language、所有组件的 props、动画令牌等提供完整且可导出的 `.d.ts` 文件。  
2. **核心单元测试**：覆盖每个组件的渲染、变体、交互、主题/语言切换、动画时长等。  
3. **集成测试**：验证 Token Playground、Custom Token Manager、Storybook Isolation、Build Settings 的业务流程。  
4. **端到端（E2E）测试**：使用 Playwright 走通主题切换、语言切换、令牌导入/导出、构建生成等关键路径。  
5. **可访问性（A11y）测试**：使用 jest‑axe 对所有交互组件检查颜色对比度、ARIA、键盘可达性。  
6. **性能基准**：在 CI 中运行 lighthouse‑ci，确保 FCP ≤ 1.5 s、LCP ≤ 2.5 s、CLS ≤ 0.1、总资源 ≤ 500 KB。  
7. **视觉回归**：配置 Chromatic，自动在每次 PR 中生成截图并对比差异。  
8. **CI/CD**：GitHub Actions 工作流覆盖 **typecheck → lint → test → coverage → build → performance → visual‑regression → deploy**。  
9. **代码质量**：提供 ESLint、Prettier、Husky、lint‑staged 配置，强制 `npm run typecheck && npm run lint && npm test -- --coverage` 成功后才允许提交。  
10. **文档**：在 `docs/quality/README.md` 中编写 QA 流程、运行指令、阈值说明、故障排查指南。

### 输出要求
请在 **一次回复**中 **一次性返回** 所有文件的完整内容，使用 **GitHub Flavored Markdown** 代码块分隔，每个文件的路径写在代码块的第一行注释（`// path: <文件相对路径>`），示例：

```ts
// path: src/types/tokens.d.ts
export interface ColorToken {
  oklch: string;   // e.g. "oklch(0.62 0.14 210)"
  hex: string;     // fallback, e.g. "#3A9FFB"
  foreground: string;
}
...
```

下面列出需要生成的文件清单（**务必全部生成**）：

### Ⅰ️⃣ 类型定义（TypeScript Declaration）
| 文件路径 | 内容要点 |
|--------|----------|
| `src/types/tokens.d.ts` | `ColorToken`, `ShadowToken`, `RadiusToken`, `ShadowValue`, `TypographyToken`, `AnimationToken`, `ThemeTokens`（包括 `light` 与 `dark`）|
| `src/types/theme.d.ts` | `ThemeMode = 'light' | 'dark'`, `VisualTheme = 'future' | 'cyber' | 'business'`; `ThemeContextValue` 接口，`useTheme` 返回值 |
| `src/types/language.d.ts` | `Locale = 'zh' | 'en'`; `LanguageContextValue` 接口；`TFunction` 类型 `t(key: string): string` |
| `src/types/components.d.ts` | 为所有 26+ 组件统一导出 **Props** 接口（`ButtonProps`, `InputProps`, `CardProps`, `AnimatedProps`, `ThemeToggleProps`, `LanguageToggleProps`, `CustomTokenManagerProps`, `StorybookIsolationProps`, `BuildSettingsProps`），并使用 **泛型** 与 **Polymorphic**（`as?: React.ElementType`） |
| `src/types/animation.d.ts` | `AnimationKey = keyof typeof animationTokens['duration']`; `EasingKey`; `AnimationConfig` |
| `src/types/index.d.ts` | `export * from './tokens'; export * from './theme'; ...` 统一入口 |

### Ⅱ️⃣ ESLint / Prettier / Husky 配置
| 文件路径 | 内容要点 |
|--------|----------|
| `.eslintrc.js` | `@typescript-eslint/parser`, `plugin:react`, `plugin:jsx-a11y`, `plugin:prettier`; 规则包括 `no-unused-vars`, `prefer-const`, `react/jsx-boolean-value`, `jsx-a11y/anchor-is-valid` |
| `.prettierrc` | 使用 `singleQuote`, `trailingComma: "all"`, `printWidth: 100`, `tabWidth: 2` |
| `package.json` → `scripts` | 新增 `typecheck`, `lint`, `format`, `prepare` (husky install) |
| `husky` 文件夹 | `pre-commit` → `lint-staged` 执行 `npm run typecheck && npm run lint && npm test -- --coverage && npm run format:check` |
| `.lintstagedrc.json` | 匹配 `*.{ts,tsx,js,jsx,json,css,md}`，分别跑 `eslint --fix`, `prettier --write` |

### Ⅲ️⃣ Jest 单元 & 集成测试（使用 React Testing Library & jest‑axe）
| 文件路径 | 内容要点 |
|--------|----------|
| `jest.config.js` | `preset: 'ts-jest'`, `testEnvironment: 'jsdom'`, `setupFilesAfterEnv: ['./jest.setup.ts']`, `collectCoverageFrom: ['src/**/*.tsx','src/**/*.ts']`, `coverageThreshold: { global: { branches: 80, functions: 80, lines: 80, statements: 80 } }` |
| `jest.setup.ts` | 引入 `@testing-library/jest-dom`, `jest-axe`, `jest.useFakeTimers`（用于动画） |
| `src/__tests__/unit/Button.test.tsx` | 渲染不同 `variant`、`size`、`disabled`，检查 `style` 是否使用 `var(--color-*)`，使用 `axe` 检查可访问性，快照测试。 |
| `src/__tests__/unit/ThemeToggle.test.tsx` | 验证快捷键 `Ctrl+Alt+T` 切换，`data-theme` 正确更新，`localStorage` 持久化。 |
| `src/__tests__/unit/LanguageToggle.test.tsx` | 验证 `Ctrl+Alt+L` 切换语言，`t('nav.home')` 正确渲染中文/英文。 |
| `src/__tests__/unit/Animated.test.tsx` | 检查 `animation` prop 对应的 CSS `animation` 名称、时长使用 token，且在 `hover` 或 `click` 触发时动画执行。 |
| `src/__tests__/unit/TokenPlayground.test.tsx` | 通过 `user-event` 模拟编辑 token，确认 `onChange` 触发、`variables.css` 更新。 |
| `src/__tests__/integration/TokenManagerFlow.test.tsx` | 端到端模拟 **Import → Edit → Export → History** 流程，断言文件下载内容符合预期。 |
| `src/__tests__/integration/StorybookIsolation.test.tsx` | 开启 Isolation Mode，检查组件在独立 `iframe` 中渲染，验证 `snapshot layout` 下的 DOM 结构。 |
| `src/__tests__/integration/BuildSettings.test.tsx` | 勾选 SCSS、iOS、Android 构建，点击 **Generate**，模拟 `npm run build:*` 并断言 `progress` 达到 100%。 |
| `src/__tests__/accessibility/AllComponents.a11y.test.tsx` | 循环 `componentsList`（Button、Input、Select、Modal、Tooltip、Tab等），使用 `axe` 检测颜色对比度、ARIA 标签、键盘焦点。 |
| `scripts/verify-types.ts` | `tsc --noEmit` 并在 CI 中作为独立步骤运行。 |
| `scripts/validate-tokens.ts` | 使用 `ajv` 校验 `design/tokens.json` 是否符合 `tokens-schema.json`（你要生成的 JSON Schema），并在 CI 中报错。 |

### Ⅳ️⃣ Playwright 端到端测试
| 文件路径 | 内容要点 |
|--------|----------|
| `playwright.config.ts` | `projects` 包括 `chromium`, `firefox`, `webkit`; `baseURL: 'http://localhost:6006'`（Storybook），`use: { headless: true, viewport: { width: 1280, height: 720 } }` |
| `tests/e2e/theme-language.spec.ts` | 1️⃣ 访问 `/overview` → 验证默认中文、Light 主题；2️⃣ 按 `Ctrl+Alt+T` → Dark 主题；3️⃣ 按 `Ctrl+Alt+L` → 切换英文；4️⃣ 检查 `data-theme` 与 `html[lang]` 属性。 |
| `tests/e2e/token-manager.spec.ts` | 打开 Custom Token Manager → 拖拽上传错误的 JSON → 验证错误提示；成功上传后编辑 token → 保存 → 检查 `tokens.json` 本地文件更新（通过 `fs` 读取）。 |
| `tests/e2e/storybook-isolation.spec.ts` | 在 Storybook 中打开任意组件 → 开启 Isolation → 通过 `frameLocator` 确认 `iframe` 加载；关闭后再次检查无 `iframe`。 |
| `tests/e2e/build-settings.spec.ts` | 打开 Build Settings → 勾选所有平台 → 开始生成 → 等待进度条完成 → 检查 `dist` 文件夹出现 `variables.css`, `tokens.js`, `scss/*.scss`，并验证文件大小 < 200 KB（通过 `page.evaluate` 获取 `performance`）。 |
| `tests/e2e/performance-lhci.spec.ts` | 使用 `lighthouse` CLI 在 CI 中运行，结果写入 `lighthouse-report.json`，在 `summary` 中断言 FCP、LCP 等指标满足预算。 |

### Ⅴ️⃣ Lighthouse CI 配置
| 文件路径 | 内容要点 |
|--------|----------|
| `lighthouserc.json` | `ci: { collect: { url: ['http://localhost:6006'], numberOfRuns: 3, settings: { emulatedFormFactor: 'desktop', throttling: { rttMs: 40, throughputKbps: 10240 } } }, upload: { target: 'temporary-public-storage' } }` |
| `scripts/perf-test.sh` | `npm run preview &` → `wait-on http://localhost:6006` → `lhci autorun` → `kill $!` |

### Ⅵ️⃣ Chromatic 配置（视觉回归）
| 文件路径 | 内容要点 |
|--------|----------|
| `.chromatic.config.json` | `"projectToken": "<YOUR_CHROMATIC_TOKEN>", "storybookPort": 6006, "exitOnceUploaded": true, "autoAcceptChanges": "main"` |
| `package.json` → script | `"chromatic": "chromatic test --storybook-port 6006"` |
| `src/__tests__/visual/Card.visual.test.tsx` | 使用 `@storybook/addon-visual-tests` 或 `chromatic` 自动生成快照，无需手写代码（只需在 `package.json` 声明）。 |

### Ⅶ️⃣ GitHub Actions 工作流
| 文件路径 | 内容要点 |
|--------|----------|
| `.github/workflows/ci.yml` | 1️⃣ Checkout → 2️⃣ Setup Node (`node-version: 20`) → 3️⃣ Install (`npm ci`) → 4️⃣ **Type Check** (`npm run typecheck`) → 5️⃣ **Lint** (`npm run lint`) → 6️⃣ **Unit & Integration Tests** (`npm run test:unit && npm run test:integration`) → 7️⃣ **Coverage**（上传至 Codecov） → 8️⃣ **E2E** (`npm run test:e2e`) → 9️⃣ **Performance** (`./scripts/perf-test.sh`) → 10️⃣ **Visual Regression** (`npm run chromatic`) → 11️⃣ **Build** (`npm run build`) → 12️⃣ **Deploy Preview**（如果使用 Vercel/Netlify） |
| `.github/workflows/label-pr.yml` | 自动为 PR 打上 `type: test`, `status: pending`，并在检查结束后更新为 `passed` / `failed` |
| `.github/workflows/lint-staged.yml` | 触发 `push` / `pull_request` → 仅对 `*.{ts,tsx,js,jsx,json,css,md}` 运行 `eslint --fix` + `prettier --write` |
| `.github/workflows/deploy.yml` | 成功 `main` 分支构建后自动部署到 **GitHub Pages**（发布 Storybook）或 **Vercel**（预览站点） |

### Ⅷ️⃣ 文档（docs/quality/README.md）
**必须包括**：
- QA 流程总览图（使用 Mermaid）  
- 本地运行指令（`npm run typecheck`, `npm run test`, `npm run test:e2e`, `npm run chromatic`, `npm run perf`）  
- CI 质量阈值（Coverage ≥ 80%、Lighthouse 预算、Chromatic 成功率 = 100%）  
- 常见错误排查（例如 “jest-axe 报错 – color contrast” → 检查 `tokens.json` 中的 `foreground` 与 `background`）  
- 如何在 PR 中查看 **Chromatic** 对比截图、**Lighthouse** 报告链接、**Codecov** 覆盖率 badge。  

### Ⅸ️⃣ 额外说明（必须在每个文件顶部加注释）
- 所有 **type**、**test**、**script** 文件必须在第一行写明 **文件路径**（如 `// path: src/types/tokens.d.ts`），便于复制粘贴。  
- 所有 **测试** 必须使用 **async/await** + `await act(async () => {...})` 确保 React 更新被捕获。  
- **动画** 相关的测试要用 **jest.useFakeTimers** 并在 `advanceTimersByTime` 后断言 `animationend` 事件触发。  
- **E2E** 使用 `page.keyboard.down('Control')`、`page.keyboard.press('L')` 等组合键模拟快捷键。  
- 对 **所有** `color-`、`shadow-`、`radius-`、`animation-` token 在测试中应通过 `getComputedStyle` 读取 CSS 变量并与 **tokens.d.ts** 中的默认值进行 **deepEquality** 检查（使用 `lodash.isEqual`）。  

---

## 🎉 完成后期望的项目结构（重点展示新增文件）

```
yyc3-design-system/
├─ src/
│  ├─ types/
│  │   ├─ tokens.d.ts
│  │   ├─ theme.d.ts
│  │   ├─ language.d.ts
│  │   ├─ components.d.ts
│  │   └─ animation.d.ts
│  ├─ __tests__/
│  │   ├─ unit/
│  │   │   ├─ Button.test.tsx
│  │   │   ├─ ThemeToggle.test.tsx
│  │   │   └─ … (其他 25+ 组件)
│  │   ├─ integration/
│  │   │   ├─ TokenManagerFlow.test.tsx
│  │   │   ├─ StorybookIsolation.test.tsx
│  │   │   └─ BuildSettings.test.tsx
│  │   └─ accessibility/
│  │       └─ AllComponents.a11y.test.tsx
│  └─ utils/ (保留原有)
├─ scripts/
│  ├─ verify-types.ts
│  ├─ validate-tokens.ts
│  └─ perf-test.sh
├─ tests/
│  └─ e2e/
│      ├─ theme-language.spec.ts
│      ├─ token-manager.spec.ts
│      ├─ storybook-isolation.spec.ts
│      └─ build-settings.spec.ts
├─ .eslintrc.js
├─ .prettierrc
├─ .lintstagedrc.json
├─ jest.config.js
├─ jest.setup.ts
├─ lighthouseconfig.json
├─ chromatic.config.json
├─ .github/
│  └─ workflows/
│      ├─ ci.yml
│      ├─ label-pr.yml
│      └─ deploy.yml
├─ docs/
│  └─ quality/
│       └─ README.md
└─ package.json (已新增 scripts)
```

---

## 🚀 请 AI 按照以上清单 **一口气生成**（一次性回复）全部文件内容。  
每个文件必须：

1. **保持完整可直接复制的代码块**（不遗漏任何 `import` / `export`）；
2. **符合 TypeScript 严格模式**（`"strict": true`）；
3. **遵守项目已有的命名约定**（如 `color-primary`, `spacing-2`, `animation-duration-fast`）；
4. **在注释中标明文件路径**（如 `// path: src/types/tokens.d.ts`）；
5. **在测试文件中使用 `import { render, screen, fireEvent } from '@testing-library/react';`**，并 **加入 `await axe(container)`** 做可访问性检查；
6. **在 CI 配置中使用 `actions/setup-node@v4`**，并 **缓存 `node_modules`** 以加速；
7. **所有脚本都使用 `#!/usr/bin/env node`** 并 **export default**（如果是 ES‑module）；

完成后，请在回复的最底部提供一个 **快速检查表**（Check List），帮助开发者确认所有文件已就位。

--- 
