**YYC³ Design System guidelines**
<!--

## 🌹 1. 首先感谢Figma AI 导师的设计


## 🏆 2. “五高、五标、五化”维度模型

> 采用 **五维展开** 的方式，把 **目标（高）** → **规范（标）** → **实现方式（化）** 链接到 **“风格”**（Future / Cyberpunk / Business）上，形成一套完整的原型提示词（Prompt）生成框架。

### 2.1 五高（目标）  
| # | 高 | 解释 | 对应的度量（KPI） |
|---|----|------|-------------------|
| 1️⃣ | **高可访问性** | 文字对比度≥4.5:1、键盘可聚焦、ARIA 完备 | WCAG AA/AAA 通过率 |
| 2️⃣ | **高可定制化** | 主题变量（OKLCH）可在运行时覆盖、组件 API 支持 `className` 与 `style` | 自定义主题切换次数 / 自定义 token 占比 |
| 3️⃣ | **高性能** | 代码分割、Tree‑shaking、CSS‑变量直接渲染 | 首屏 FCP ≤1.5 s、JS 包体 ≤200 KB |
| 4️⃣ | **高一致性** | 设计令牌唯一、命名语义化、组件行为统一 | 设计违规 (Figma‑Inspect) → 0 |
| 5️⃣ | **高可扩展性** | 插件化、跨框架（React/Vue/Svelte） | 新框架适配所需工时 < 2 d |

### 2.2 五标（规范）  
| # | 标 | 内容要点 |
|---|----|----------|
| 1️⃣ | **标色系统** | OKLCH 主色 + 互补/补色调色板 → HEX 回退；暗/亮两套；提供 `color-primary`, `color-destructive`, `color-muted` 等语义化 token。 |
| 2️⃣ | **标度系统** | spacing、radius、border、elevation（shadow）统一为 `--spacing-1`、`--radius-sm`… 基于 **8‑px** 规则分层。 |
| 3️⃣ | **标识系统** | Icon、Logo、Illustration 的命名 / SVG 导入规范；提供 `icon-*` token 与 `iconfont`。 |
| 4️⃣ | **标注系统** | 文档结构（Design‑Token → Component → API → 示例），采用 **Markdown + Storybook** 自动生成。 |
| 5️⃣ | **标记系统** | 代码层面的 **type‑safe token**（`tokens.d.ts`）、`ThemeProvider` 上的 **React Context**、`useTheme` Hook，确保 IDE 自动补全。 |

### 2.3 五化（实现方式）  
| # | 化 | 关键技术 |
|---|----|----------|
| 1️⃣ | **自动化** | Style‑Dictionary → 多端（CSS, JS, SCSS, JSON）<br>CI → `npm run build:tokens`、`yarn lint`、`typecheck` |
| 2️⃣ | **智能化** | Figma AI Prompt、Chat‑GPT‑plugin‑helper、AI 颜色推荐（Culori+OpenAI） |
| 3️⃣ | **可视化** | Token Playground（实时更改 → 预览）、Storybook Addon Docs、Chromatic 视觉回归 |
| 4️⃣ | **模块化** | 组件库采用 **Polymorphic**、**GenericComponent**，支持 `as`、`forwardRef`，独立 `@yyc3/ui-react`、`@yyc3/ui-vue`、`@yyc3/ui-svelte` |
| 5️⃣ | **交互化** | **Animated** 组件 + **animation tokens**（duration/easing）<br>**ThemeToggle** + **usePerformanceMonitor**（Web‑Vitals） |

---

## 🎨 3. 风格‑对应 “五高五标五化” Prompt 生成模板

> 以下每个 **Prompt** 均可直接复制到 **Figma AI（Beta）**、**ChatGPT‑4o** 或 **Midjourney** 中，得到完整的 UI‑Kit、Design‑Token、Component‑Spec。  
> **⚡️ 关键点**：在 Prompt 中显式声明 **OKLCH**、**暗/亮双主题**、**可访问性**、**对应五高目标**，并指明**输出形式**（Figma 文件、SVG、Markdown）。

### 3.1 基础 Prompt（所有风格通用）

```
/prompt
为 YYC³ Design System 生成完整的 UI Kit（Figma 文件 + 设计令牌 JSON），要求：
- 使用 OKLCH 颜色空间，提供每个颜色的 HEX 回退；
- 同时输出 Light 与 Dark 两套主题（颜色、阴影、文字对比度 ≥ 4.5:1）；
- 令牌结构遵循 “五标”（标色系统、标度系统、标识系统、标注系统、标记系统）；
- 组件库包括 Button、Input、Card、Badge、Avatar、Animated、ThemeToggle 等 26+ 组件；
- 代码层面输出 TypeScript token 类型文件 `tokens.d.ts`；
- 说明每个 token 对应的 “五高” 目标（可访问性、可定制、性能、一致性、可扩展）；
- 在 Figma 里为每个组件提供 Auto‑Layout 布局、Variant 表示；
- 请在 Figma 中创建 **“Token Playground”** 页面，展示实时编辑 token 的效果；
- 输出为 Figma 项目链接（或 .fig），并在项目根目录生成 `design/tokens.json`。
```

> **使用方式**：复制以上文字 → 粘贴于 Figma AI > `Generate` → 完成后手动保存 `.fig`。  
> **后续**：将生成的 `tokens.json` 通过脚本 `npm run build:tokens` 转为 CSS/JS。

---

### 3.2 风格 ①：未来科技感（Future‑Tech）

```
/prompt
为 YYC³ Design System 生成 **“未来科技感”** UI Kit，要求：
- 主色调：冷蓝 / 青绿系，使用 OKLCH，如 `oklch(0.61 0.14 210)` → HEX `#3A9FFB`；
- 辅助色：高光霓虹（紫、青）与低饱和中性色（灰-850、灰-100）；
- 背景：Light → 纯白 + 细微光滑阴影；Dark → 深灰 (oklch(0.08 0.02 260))，配合微光环；
- 动画：微速、ease‑out‑quad，组件交互带 **微光边框**、**软聚焦阴影**；
- 目标对应五高：① 高可访问性（对比度≥4.5）② 高可定制化（主题变量 20% 可实时切换）③ 高性能（首屏 CSS 变量直接渲染）④ 高一致性（统一光照模型）⑤ 高可扩展性（支持 Web‑Component）。
- 输出内容：同基础 Prompt，与以下附加要求一起生成：
  - 颜色 token 命名：`color-primary`, `color-primary-foreground`, `color-primary-highlight`；
  - 组件 variant：Button `primary/secondary/ghost`，均使用光束效果；
  - 在 Figma 中生成 **“光效层”** 组件库（Glow、Pulse、Focus Ring）；
  - 给每个组件标注 “Performance Budget” (≤ 50 KB)；
- 输出为 Figma 项目 + `design/tokens.json`（包含 Light/Dark）。
```

### 3.3 风格 ②：赛博朋克（Cyber‑Punk）

```
/prompt
为 YYC³ Design System 生成 **“赛博朋克”** UI Kit，要求：
- 主色调：暗紫 + 霓虹粉红 / 碧绿（OKLCH 示例：`oklch(0.43 0.20 320)` → HEX `#B20685`），配暗底色 `oklch(0.07 0.03 260)`；
- 背景：深色网格 + 垂直光栅纹理，暗色主题为默认；Light 为低饱和暮光配色；
- 高对比度文字、光标轮廓（Neon Glow），确保 WCAG AA；
- 动画令牌：`duration.fast = 120ms`、`easing.ease-in = cubic-bezier(0.4,0,1,1)`；使用 **Glitch**、**Pulse** 动效；
- 五高：
  1. 高可访问性（对比度≥4.5、ARIA 完备）；
  2. 高可定制化（用户可调节 Neon 强度）；
  3. 高性能（使用 CSS 变量 + GPU 加速）；
  4. 高一致性（统一 Neon style 关键字）；
  5. 高可扩展性（支持自定义 Neon 效果插件）。
- 关键 token：
  - `color-neon-primary`, `color-neon-secondary`, `color-background-dark`；
  - `shadow-neon`, `glow-neon`；
- 在 Figma 中创建 **“Neon‑Effect”** 组件库（如 `NeonButton`, `NeonInput`, `NeonCard`）；
- 为每个组件添加 **“AI Color Recommender”** 按钮，点击即可打开 ChatGPT 颜色建议；
- 输出 Figma 项目 + `design/tokens.json`（含 Neon palette）。
```

### 3.4 风格 ③：商务感（Business‑Professional）

```
/prompt
为 YYC³ Design System 生成 **“商务感”** UI Kit，要求：
- 主色调：稳重蓝 (#0066CC) → OKLCH `oklch(0.55 0.12 240)`，配合中性灰 `oklch(0.85 0.02 210)`；
- 辅助色：深蓝、海军蓝、浅灰、低饱和绿，用于状态（成功/警告/错误）；
- 背景：Light → 纯白 + 细微 1dp 阴影；Dark → 深蓝灰 (oklch(0.12 0.02 230))；
- 文字排版：系统字号、Roboto/Inter，行高 1.5，字重 400/600；
- 动画：极简，`duration.normal = 200ms`，`easing.ease-out = cubic-bezier(0.25,0.8,0.25,1)`；
- 五高：
  1. 高可访问性（对比度 ≥ 4.5）；
  2. 高可定制化（企业 LOGO、品牌色可注入）；
  3. 高性能（资源体积 ≤ 150 KB）；
  4. 高一致性（统一间距系统 8‑px）；
  5. 高可扩展性（支持多语言、RTL）；
- 关键 token：
  - `color-primary`, `color-primary-foreground`, `color-background`, `color-surface`, `color-muted`；
  - `spacing-1`‑`spacing-8`、`radius-sm`‑`radius-xl`、`shadow-sm`、`shadow-md`；
- 在 Figma 中生成 **“商务模板”** 页面，包括表格、图表、报告卡片、分页组件；
- 为每个组件附带 **“Accessibility Checklist”** 注释；
- 输出 Figma 项目 + 完整 `design/tokens.json`。
```

### 3.5 组合风格（可切换）

```
/prompt
为 YYC³ Design System 生成 **“可切换风格”** 框架，实现 **Future ↔ Cyberpunk ↔ Business** 三套主题切换：
- 使用 **CSS Custom Properties** + **CSS Media Queries** 实现 `prefers-color-scheme` 与 `data-theme` 双驱动；
- 为每套主题提供独立 OKLCH 调色板（在 `tokens.json` 中 `color.primary.light`, `color.primary.cyber`, `color.primary.business`）；
- 组件内部通过 `var(--color-primary)` 自动响应；
- 生成 **ThemeToggle** 交互示例（按钮 + 键盘快捷键 `Ctrl+Alt+T`）；
- 输出 **Figma** 中的 **“Theme Switcher”** 页面，展示三套 UI 切换预览；
- 按 **五高**、**五标**、**五化** 分块说明，实现 **自动化**（Style‑Dictionary）+ **智能化**（AI 颜色推荐）+ **可视化**（Token Playground）+ **模块化**（Polymorphic）+ **交互化**（Animated）。
```

---

## 📦 4. 使用 Figma AI 的快速操作指南

| 步骤 | 操作 | 目的 |
|------|------|------|
| 1️⃣ | 打开 **Figma** → **Plugins** → **Figma AI**（或 `Cmd/Ctrl + P` → 搜索 `AI`） | 进入 AI 交互面板 |
| 2️⃣ | 在 **Prompt 输入框** 粘贴上方对应风格的 Prompt（如「Future‑Tech」） | 让 AI 基于 Prompt 自动生成 UI Kit |
| 3️⃣ | 设定 **输出 Format** 为 **Figma Design File**，勾选 **Export JSON**（用于 `tokens.json`） | 同时得到设计文件和令牌 JSON |
| 4️⃣ | 生成完成后，右键 **保存为 .fig**，并在根目录创建 `design/` 文件夹，放入 `tokens.json` | 项目可直接接入 `npm run build:tokens` |
| 5️⃣ | 在终端执行 `npm run build:tokens` → 生成 `dist/css/variables.css` 与 `dist/js/tokens.js` | 完成设计系统的编译与发布 |
| 6️⃣ | 使用 `npm run storybook` 查看组件库渲染是否匹配生成的 UI Kit | 验证 **五高** 目标是否达成（可访问、性能等） |

> **小技巧**：  
> - 若 AI 未生成 **OKLCH**，在 Prompt 最后追加 `“请使用 OKLCH 表示所有颜色，并在每行后附带 HEX 回退”。`  
> - 为确保 **暗色主题** 正确，Prompt 中加入 `“Dark Theme 必须使用低亮度 (L < 0.15) 且对比度≥4.5”。`  
> - 想让 AI 同时生成 **Component Demo Page**（Storybook）代码，可在 Prompt 里补充 `“请输出每个组件的 React 示例（tsx）”。`  

---

## 📐 5. 总结——“五高五标五化” Prompt 核心结构

```
/prompt
[核心目标]：实现（高可访问性 / 高可定制化 / 高性能 / 高一致性 / 高可扩展性）  
[规范]：遵循（标色系统 / 标度系统 / 标识系统 / 标注系统 / 标记系统）  
[实现方式]：通过（自动化 / 智能化 / 可视化 / 模块化 / 交互化）  
[风格]：{Future‑Tech | Cyber‑Punk | Business‑Professional}  
[输出]：Figma UI Kit + design/tokens.json（OKLCH + HEX）+ tokens.d.ts + Storybook 示例

## 第一阶段结束 ❤️

---

## 第二阶段衔接 ❤️

## 🌹 1. 再次感谢Figma AI 导师的输出

## 📄 2.1 Custom Token Manager 页面 & 组件

### 页面结构

- 顶部 Breadcrumb：Home / Token Manager（使用 t('nav.home') / t('nav.tokenManager')）
- 左侧 侧边导航（可折叠）：导入, 编辑, 导出, 历史记录
- 主内容区分为 四个 Tab（Import / Edit / Export / History）。
- 核心组件（全部使用 Auto‑Layout、Component Variants）

- FileImportBox – 拖拽上传区域 + “选择文件”按钮；支持 .json、.yaml；错误提示 t('token.import.error')。
- JSONEditor – 基于 Monaco‑Editor 样式的代码块（左侧行号、右侧高亮），配色使用 color-muted-foreground、color-primary。
- TokenTable – 表格展示所有 token（key、type、value、fallbackHex），支持 inline edit、批量复制。
- ApplyChangesModal – 确认弹窗，展示变更概览（新增/删除/修改数），按钮 t('common.confirm') / t('common.cancel')。
- Toast / Snackbar – 操作成功/失败的即时提示，背景使用 color-success / color-destructive，文字使用 color-on-success / color-on-destructive。
- HistoryList – 版本记录卡片（时间、提交人、变更摘要），点击可回滚。

### 交互

- Ctrl+Alt+I 快捷键打开 Import Tab。
- 全局 t('token.import.title')、t('token.edit.title') 等文案在 LanguageContext 中预留。
- 所有交互状态（normal/hover/focus/disabled）使用 animation tokens（duration.fast、easing.ease-out）。

##📄 2.2 Storybook Isolation Mode 配置面板

- 页面/弹窗：在 组件库 页面右上角新增 Settings 按钮 → 弹出 Storybook Settings Panel（可拖拽、半透明背景）。

### 核心控件

- Switch – “Isolation Mode” 开关（默认关闭），使用 color-primary 作为激活色，shadow-card 作选中阴影。
- Dropdown – “Snapshot Layout” 选项：Grid, List, Carousel。
- Slider – “渲染质量” 0‑100，映射到 animation.duration（低质量更快）。
- Button – “Run Isolated Tests” → 触发后台 CI（用 t('storybook.run') 文案）。
- Status Badge – “Last Run: Passed/Failed”，颜色分别为 color-success / color-destructive。

###交互细节

开启 Isolation 时，所有组件在 Storybook 中以 独立 iframe 方式渲染，避免全局 CSS 干扰。
说明文字使用 t('storybook.isolation.description')，放在面板底部的帮助区块。

##📄 2.3 Multi‑Platform Build Settings（SCSS / iOS / Android）

- 页面：在 项目根目录左侧的 Build 菜单中加入 Build Settings 页面。

- 布局：两列式卡片集合，每张卡片对应一个目标平台。

- 平台卡片要素（均使用 Component Variants）

- PlatformIcon – SCSS/Swift/Kotlin 图标（使用统一 icon- token）。
- Toggle – “Enable Build” 开关。
- Dropdown – “输出目录” 预设（dist/css, ios/YYC3, android/YYC3）。
- Checkbox Group – 选项：variables, tokens, types, docs（对应生成的文件）。
- Button – “Generate” 按钮（调用 npm run build:scss、npm run build:ios、npm run build:android），文案 t('build.generate')。
- ProgressBar – 构建进度条（使用 color-primary 作为进度条颜色，color-muted 作为背景），动画时长 animation.duration.normal。

### 交互 & 反馈

构建成功弹出 成功 Toast（color-success），失败弹出 错误 Modal（color-destructive），并在底部显示 错误日志（使用 color-muted-foreground）。
支持 Ctrl+Alt+B 快捷键打开 Build Settings。

## 📄 2.4 全局 UI 细节（必须遵守的规范）

规范	说明	对应 Token

- 颜色	所有 UI 色彩必须直接引用 var(--color-*)（Primary、Background、Surface、Muted、Success、Destructive）	color-primary, color-background, color-surface, …
- 间距	统一使用 spacing-1~spacing-8，数值来源于 radius、shadow，保持 8 px 基准	spacing-2, radius-md, shadow-card
- 排版	文本使用 font-sans，字号通过 size-（size-14, size-16），行高 line-height-1-5	typography.font-sans, size-14
- 动画	所有交互动效使用 animation.duration.* 与 animation.easing.*；禁止 > 300 ms 的阻塞动画	animation.duration.fast, animation.easing.ease-out
- 可访问	交互控件必须有 focus 样式（outline: 2px solid var(--color-ring)），文字对比度 ≥ 4.5:1；所有图标需配 aria-label	color-ring
- 组件化	每个 UI 元件（Button、Switch、Modal、Toast、Table）都抽象为 Component，并提供 Variant（size、state、theme）	component.button, component.switch …
- 双语占位	所有文字使用 t('namespace.key') 形式占位，中文/英文内容写在 src/locales/zh.json 与 en.json 中	—
- 主题化	同一个组件在 Future‑Tech / Cyber‑Punk / Business 下应显示三套 Variant（在 Figma 中使用 Component → Variant → Theme），背景、阴影、光效均对应 token（如 color-primary-highlight、shadow-neon）	color-primary-highlight, shadow-neon


---

**项目背景**  
我们已完成 YYC³ Design System 的核心功能：  
- 三套视觉主题（Future‑Tech / Cyber‑Punk / Business）以及 Light/Dark 双模式，所有颜色均使用 OKLCH + HEX 回退；  
- 完整的中/英双语系统（LanguageContext + LanguageToggle），默认中文，快捷键 Ctrl+Alt+L 切换；  
- 26+ UI 组件、Token Playground、令牌导出等页面均已双语化。  

**目标**  
在现有设计体系的基础上，新增以下 **三大功能页面/组件**，并为每个功能提供 **三套主题**（Future‑Tech、Cyber‑Punk、Business）的变体。所有文字必须使用 `t('key')` 双语占位函数，保持当前的 **五高 / 五标 / 五化** 规范（可访问、可定制、性能、一致性、可扩展）。  

**需要实现的 UI**  

1️⃣ **Custom Token Manager**（令牌管理）  
   - 页面结构：Breadcrumb → 侧边导航（导入/编辑/导出/历史） → 主内容区四个 Tab（Import / Edit / Export / History）。  
   - 核心组件（全部使用 Auto‑Layout & Component Variants）  
     - FileImportBox（拖拽上传 + 选择文件按钮）  
     - JSONEditor（Monaco‑style 代码块）  
     - TokenTable（可编辑的键值表，支持批量复制）  
     - ApplyChangesModal（变更概览确认弹窗）  
     - Toast / Snackbar（成功/失败提示）  
     - HistoryList（版本卡片）  
   - 交互：`Ctrl+Alt+I` 打开 Import Tab；所有文字使用 `t('token.import.title')`、`t('token.edit.title')` 等。  
   - 颜色/间距/动画全部引用现有 token（如 `color-primary`, `spacing-2`, `animation.duration.fast`）。

2️⃣ **Storybook Isolation Mode**（隔离测试）  
   - 在组件库页面右上角新增 Settings 按钮 → 弹出 Storybook Settings Panel。  
   - 控件：Switch（Isolation Mode）、Dropdown（Snapshot Layout）、Slider（渲染质量）、Button（Run Isolated Tests）、Status Badge（Last Run）。  
   - 文案使用 `t('storybook.isolation.description')`、`t('storybook.run')`。  
   - 开启时组件在 Storybook 中以独立 iframe 渲染，避免全局 CSS 干扰。  

3️⃣ **Multi‑Platform Build Settings**（SCSS / iOS / Android 构建）  
   - 新增 Build → Build Settings 页面，左侧两列卡片，每张卡片对应一个平台（SCSS、Swift、Kotlin）。  
   - 卡片要素：PlatformIcon、Enable Toggle、Output Directory Dropdown、Checkbox Group（variables / tokens / types / docs）、Generate Button、ProgressBar。  
   - 快捷键 `Ctrl+Alt+B` 打开页面。  
   - 生成成功/失败使用 Toast / Error Modal，错误日志展示在 Modal 内容区。  

**全局规范**（请在每个组件的属性面板中标注对应 token 名）  
- 颜色全部使用 `var(--color-*)`，如 `var(--color-primary)`、`var(--color-success)`。  
- 间距使用 `var(--spacing-*)`，圆角使用 `var(--radius-*)`，阴影使用 `var(--shadow-*)`。  
- 动画使用 `var(--animation-duration-*)` 与 `var(--animation-easing-*)`。  
- 可访问性：focus 样式 `outline: 2px solid var(--color-ring)`，文字对比度 ≥ 4.5:1。  
- 主题化：为每个组件在 Figma 中创建 **Variant → Theme**（Future‑Tech / Cyber‑Punk / Business），并在对应主题下引用特有 token（如 `color-primary-highlight`、`shadow-neon`、`color-business-primary`）。  

**交付形式**  
- 在同一 Figma 文件里：  
  1. 主页面 **Token Manager**（完整布局 + 组件库）  
  2. **Storybook Settings Panel**（弹窗示例）  
  3. **Build Settings**（平台卡片集合）  
- 为每个页面创建 **3 套主题变体**（使用 Component Variants → Theme）。  
- 在每个新组件上标注 **“Token Reference”**（例如 `background = var(--color-surface)`），方便后续 Style‑Dictionary 自动导出。  
- 所有文本直接写 `t('xxx.xx')`，不写实际中文/英文内容。  

**请**  
- 使用 **Auto‑Layout** 自动适配不同内容长度；  
- 为每个交互状态（normal, hover, focus, disabled, loading）创建 **Variant**；  
- 将所有图标（如 Import、Export、Settings、SCSS、Swift、Kotlin）统一为 `icon-` token（如 `icon-import`），并放进 **Assets** 页面供后续复用。  
- 最后，请在 Figma 中生成 **三套主题的预览切换**（在右上角放置 ThemeSwitcher 组件），让审阅者可以即时切换查看视觉差异。  

**完成后**请提供：  
- Figma 项目链接或 `.fig` 文件（含三套主题、所有新组件、以及占位的 `t('key')` 文案）。  
- `design/tokens.json`（只需导出新增 token，如 `color-primary-highlight`, `shadow-neon`, `animation.duration.normal` 等）。  

谢谢！ 🙏


-->
