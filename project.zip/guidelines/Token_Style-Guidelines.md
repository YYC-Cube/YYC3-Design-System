# 📋 YYC³ Design System Guidelines– 完整闭环 AI 设计 Prompt 规范  
> **目标**：一次性把 *三套主题*、*首页总览*、*顶部导航*、*组件库页面* 按 **五高 / 五标 / 五化**（可访问 / 可定制 / 高性能 / 一致性 / 可扩展） 重构为 100% 可落地、无死代码、全响应式、ARIA 完整支持、全由 CSS Custom‑Properties 驱动的 UI 套件。  
> **使用方式**：把下面的 **四段 Prompt**（或合并为一个）直接粘贴到 **Figma AI → “Generate Design”**、**ChatGPT‑4o**、**Midjourney‑Prompt‑Builder** 等工具的 Prompt 输入框中。每段 Prompt 前后都有清晰的标题与代码块，复制即可。

---

## Ⅰ️⃣ 统一设计指令（所有 Prompt 必须包含）

```text
You are a senior UI/UX AI designer for the YYC³ Design System.
All colors must be expressed in OKLCH with HEX fallback.
All spacing, radius, shadow, animation must use CSS custom properties (var(--*)).
Every component state (default, hover, focus, disabled, loading) must be a Variant.
All interactive elements must have proper ARIA attributes and visible focus rings.
Design must respect the “Five‑High / Five‑Standard / Five‑Implementation” matrix:
  • High Accessibility → WCAG AA (contrast ≥4.5:1), focus style, keyboard operability.
  • High Customizability → runtime token overrides, ThemeToggle & LanguageToggle.
  • High Performance → CSS‑variables only, no extra JS for styling, bundle ≤200 KB.
  • High Consistency → token naming, 8‑px spacing grid, unified shadow/elevation.
  • High Extensibility → Polymorphic components (as‑prop), multi‑framework ready.
Deliver the design as a **Figma file** with:
  – Auto‑Layout for every frame,
  – Component Variants for Light/Dark × 3 Themes (Future‑Tech, Cyber‑Punk, Business),
  – Responsive breakpoints: Mobile < 640 px, Tablet ≥ 640 < 1024 px, Desktop ≥ 1024 px.
All placeholder or dead code must be removed – only functional UI should exist.
```

> *把上面的文字放在每个 Prompt 的最前面，确保 AI 明白全局约束。*

---

## Ⅱ️⃣ 主题系统（Theme）Prompt

> **目的**：为三套视觉主题创建真正差异化的配色、阴影、光效，而不是仅换一个基色。每套主题都需要 Light / Dark 两个模式，全部用 OKLCH + HEX 回退。

```text
--- THEME DESIGN ---
Create three distinct visual themes for YYC³, each with Light and Dark mode.
Theme names: Future‑Tech, Cyber‑Punk, Business.

For each theme define these token groups (all in OKLCH + HEX fallback):
1. Primary palette – 5 shades (base, hover, active, disabled, foreground)
2. Secondary / Accent palette – 3 shades.
3. Background (light‑mode: okLCH(~0.98 L, 0.01 C, 0°), dark‑mode: okLCH(~0.08 L, 0.02 C, 260°).
4. Surface / Card – subtle elevation colors.
5. Success / Warning / Destructive – perceptually uniform OKLCH.
6. Ring (focus) – neon‑glow for Cyber‑Punk, crisp blue for Future‑Tech, solid navy for Business.
7. Shadows:
   • Future‑Tech – soft “glass” shadow (rgba(0,0,0,0.08) blur 12px).
   • Cyber‑Punk – colored neon shadow (e.g. okLCH(0.30 0.20 320) blur 16px).
   • Business – classic elevation (rgba(0,0,0,0.12) blur 20px).
8. Elevation levels: shadow‑sm, shadow‑md, shadow‑lg, shadow‑neon (only Cyber‑Punk).

Provide the token JSON skeleton (only keys, values are examples) like:

{
  "color": {
    "primary": {
      "value": { "oklch": "oklch(0.62 0.14 210)", "hex": "#3A9FFB", "foreground": "#FFFFFF" }
    },
    "secondary": { … },
    "background": { "light": { "oklch": "...", "hex":"#FDFDFD" }, "dark": { … } },
    "ring": { "future": { "oklch":"oklch(0.48 0.10 210)", "hex":"#5B9CE1" }, "cyber":{…}, "business":{…} },
    "shadow": {
      "future": { "x":"0", "y":"4px","blur":"12px","color":"rgba(0,0,0,0.08)" },
      "cyber":  { "x":"0", "y":"4px","blur":"16px","color":"oklch(0.30 0.20 320)"},
      "business":{ "x":"0","y":"6px","blur":"20px","color":"rgba(0,0,0,0.12)" }
    }
  },
  "radius": { "default":"0.5rem", "sm":"0.125rem", … },
  "shadow": { "card":"var(--shadow-md)" },
  "animation": { "duration":{ "fast":"120ms", "normal":"300ms", "slow":"500ms" }, "easing":{ … } }
}
```

> **提示**：每套主题的颜色必须在色相、饱和度、明度上有实质差异，尤其 Cyber‑Punk 需要带有 **紫‑粉‑绿霓虹**，Future‑Tech 带 **冷蓝/青**，Business 带 **稳重海军蓝**。  

---

## Ⅲ️⃣ 首页总览（Overview）Prompt

> **痛点**：当前页面只有死代码卡片、没有实际价值。  
> **需求**：重新布局，展示 **五高/五标/五化**，提供快速入口、最新动态、主题切换等。

```text
--- HOME OVERVIEW REDESIGN ---
Design the YYC³ “Overview” page (public route “/”). Remove all placeholder cards.
Structure the page into the following sections (auto‑layout, responsive):
1️⃣ Hero Banner (full‑width, height 56vh on desktop, 40vh on mobile):
   - Background: gradient from theme primary to accent (use CSS var).
   - Centered YYC³ logo (vector) + tagline: 
     *zh*: 「言启象限·语枢未来」 
     *en*: “Words Initiate Quadrants, Language Serves the Future”.
   - ThemeToggle (right‑top) and LanguageToggle (left‑top) icons with focus rings.

2️⃣ Five‑High Value Cards (grid 3‑col desktop, 2‑col tablet, 1‑col mobile):
   - Card title = each “High” (Accessibility, Customizability, Performance, Consistency, Extensibility).
   - Inside each card: short description (≈2 lines), an icon (from `icon-*` token), and a CTA button “了解更多 →” that links to the corresponding section on the page.
   - Use CSS var `--shadow-card` for elevation; hover = `--shadow-lg` + subtle scale.

3️⃣ Feature Grid (2‑row × 3‑col, responsive):
   - Tiles: “Component Gallery”, “Token Playground”, “AI Assistant”, “Theme Playground”, “Docs & Guides”, “Community”.
   - Each tile is a clickable card with an illustration (use `icon‑component`, `icon‑playground` …), a brief label, and a hover animation defined by `animation.duration.fast` & `animation.easing.ease-out`.
   - All tiles must have `role="link"` and `aria-label`.

4️⃣ Latest Updates / News Carousel (auto‑play, pause on hover):
   - Show 3 latest release notes (title, short date, short blurb). Use `Typography` tokens for heading/body.
   - Provide left/right navigation arrows (accessible with `aria-controls`).

5️⃣ Footer:
   - Compact, dark‑mode background, links: Home, Components, Tokens, Docs, GitHub.
   - Include a tiny “Version: v1.3.0” badge.

All text must be rendered via the i18n function `t('overview.hero.title')` etc.; no hard‑coded strings.
All components must use the token system (`var(--color-background)`, `var(--spacing-4)`, `var(--radius-md)`) and respect Light/Dark + Theme switches.
No dead code – every element present on the page must have a functional purpose (link, button, navigation).
```

> **交付**：在 Figma 中创建 **5** Frames（Desktop, Tablet, Mobile），每帧对应上面 5‑section 结构，页面整体使用 **Auto‑Layout**，并把 **Theme** 与 **Language** Switch 设为 **Component Variants**（Light/Dark × 3 Themes）。

---

## Ⅳ️⃣ 顶部导航栏（Header / Navbar）Prompt

> **痛点**：导航文字拥挤、在不同尺寸下堆叠、缺乏可访问的键盘交互。  
> **需求**：全响应式、层级清晰、支持键盘、ARIA、焦点指示，最多保留 5‑6 项主要链接。

```text
--- RESPONSIVE NAVIGATION BAR ---
Design a clean, responsive header for YYC³ with the following constraints:

1️⃣ Layout:
   - Desktop (≥1024 px): left‑aligned logo, central navigation links (max 5), right‑aligned utility icons (ThemeToggle, LanguageToggle, GitHub link).
   - Tablet (640 px‑1023 px): collapse navigation into a **mid‑header** with a hamburger menu on the left, logo centered, utility icons on the right.
   - Mobile (<640 px): full‑screen slide‑out drawer (70% width) triggered by hamburger; drawer contains navigation links stacked vertically, each with an icon (`icon-home`, `icon-components`, `icon-tokens`, `icon-docs`, `icon-community`).

2️⃣ Navigation Items (example):
   - Home (`/`)
   - Components (`/components`)
   - Tokens (`/tokens`)
   - Playground (`/playground`)
   - Docs (`/docs`)

3️⃣ Accessibility:
   - Use `<nav aria-label="Primary navigation">`.
   - Each link must have `role="link"` + `aria-current="page"` for the active route.
   - Hamburger button: `button[aria-controls="nav-drawer"]`, `aria-expanded` toggles.
   - Focus ring: `outline: 2px solid var(--color-ring)`.
   - Keyboard: Tab order cycles through logo → links → utility icons → hamburger (mobile).

4️⃣ Styling:
   - Background: `var(--color-surface)`; on scroll add slight elevation via `var(--shadow-sm)`.
   - Text: use `var(--font-sans)` and `var(--size-14)` (adjust for breakpoint).
   - Hover: subtle background change `var(--color-muted)` + `--duration-fast`.
   - Active/Current: `font-weight: 600; color: var(--color-primary)`.

5️⃣ Interaction:
   - ThemeToggle & LanguageToggle are embedded as small icon‑buttons with aria‑labels “切换主题 / Switch Theme” and “切换语言 / Switch Language”.
   - GitHub icon links to repository, opens in new tab with `rel="noopener noreferrer"`.

Deliver three Component Variants for the NavBar:
   - Desktop, Tablet, Mobile.
   - Each variant must expose a `isOpen` boolean for the mobile drawer (used by a React state hook).

All dimensions, colors, spacing must reference token vars (`--spacing-2`, `--radius-sm`, `--color-primary`, `--shadow-md`). No hard‑coded pixel values.
```

> **交付**：在 Figma 中完成 **Header** 组件的 **3** Variants（Desktop / Tablet / Mobile），并为每个 Variant 添加 **Auto‑Layout**，隐藏/显示逻辑通过 **Component Properties**（`isOpen`）展示。

---

## Ⅴ️⃣ 组件库页面（Component Gallery）Prompt

> **需求**：展示 **26** 组件的真实、可交互的示例，提供筛选功能，保持 ARIA 完整，所有样式通过 token。

```text
--- COMPONENT GALLERY PAGE DESIGN ---
Create the YYC³ “Component Gallery” page (`/components`) with the following structure:

1️⃣ Header (reuse the NavBar component).

2️⃣ Filter Bar (sticky, top‑of‑grid):
   - Search input (placeholder = t('components.filter.search')).
   - Chip groups: Category (Form, Layout, Data, Feedback, Navigation), 
     Variant (Primary, Secondary, Ghost, Outline), 
     Accessibility (ARIA‑Ready, Keyboard‑Only).
   - Each chip is a toggle button with `role="checkbox"` and `aria-checked`.
   - Use token `--color-primary` for selected chips, `--color-muted` for unselected.

3️⃣ Component Grid:
   - Responsive: 4‑col desktop (≥1200 px), 3‑col tablet (≥768 px), 2‑col mobile (≥480 px), 1‑col <480 px.
   - Each cell is a **Polymorphic Component Card**:
        • Top: component preview (real interactive preview, e.g., a functional Button that can be clicked).
        • Middle: component name (`<Button/>`) as a `<code>` element using `var(--font-mono)`.
        • Bottom: short description (≈1‑2 lines) using the i18n key `components.{name}.desc`.
        • Action: a small “Copy JSX” button (tooltip: “复制 JSX / Copy JSX”) that copies a ready‑to‑use import + JSX snippet.
   - Cards must have focus style (`outline: 2px solid var(--color-ring)`) and hover elevation (`var(--shadow-lg)`).

4️⃣ Accessibility Panel (collapsible on the right side):
   - Shows a summary of ARIA roles for the selected component (e.g., `<Button>` → `role="button"`).
   - Provides a list of required keyboard shortcuts and ARIA attributes.
   - Toggle visibility via an eye‑icon button, aria‑label “可访问性信息 / Accessibility Info”.

5️⃣ Theming & Language Switch (persistent at top‑right of the page, same as NavBar).

6️⃣ Token Reference Mini‑Panel (optional slide‑out):
   - When a component is selected, show the CSS vars it uses (e.g., `--color-primary`, `--radius-md`, `--shadow-sm`).

All components must be **fully functional** in the prototype (e.g., Buttons react to click, Switch toggles, Modal opens).  
No placeholder or dead code – each component demo must contain at least one interactive state.  
All interactions must be **keyboard accessible** (`Tab` → focus → `Enter/Space` activation).  
All visual properties (color, spacing, radius, shadow, animation) must reference the token system (`var(--*)`).

Deliver in Figma:
   - One **Page** named “Component Gallery”.
   - Frames for Desktop, Tablet, Mobile breakpoints.
   - Component cards built as **Component** (with `as` variant) so they can be reused in code generation.
   - Include **Prototype Links** to show interaction (e.g., clicking “Copy JSX” opens a toast).
```

---

## Ⅵ️⃣ 设计令牌与全局样式指南（Token & Style Guidelines）

> **所有 Prompt 必须遵守的硬性规范**（在 Figma 中添加注释，或在 README 中列出）。

| 项目 | 规范 | 示例 |
|------|------|------|
| **颜色** | OKLCH 主色 + HEX 回退；所有颜色均在 `src/styles/theme.css` 中声明为 `--color-*`。| `--color-primary: oklch(0.62 0.14 210); /* #3A9FFB */` |
| **间距** | 8 px 基准网格；变量 `--spacing-1` = 4 px, `--spacing-2` = 8 px … `--spacing-8` = 48 px。| `padding: var(--spacing-3) var(--spacing-4);` |
| **圆角** | `--radius-sm` = 0.125 rem, `--radius-md` = 0.25 rem, `--radius-lg` = 0.5 rem。| `border-radius: var(--radius-md);` |
| **阴影** | `--shadow-sm`, `--shadow-md`, `--shadow-lg`, `--shadow-neon`（仅 Cyber‑Punk）。| `box-shadow: var(--shadow-md);` |
| **动画** | `--duration-fast` = 120 ms, `--duration-normal` = 300 ms, `--easing-out` = cubic-bezier(0.25,0.8,0.25,1)。| `transition: all var(--duration-fast) var(--easing-out);` |
| **字体** | `--font-sans` = "Geist, system-ui, -apple-system, …"; `--font-mono` = "Roboto Mono, monospace"。| `font-family: var(--font-sans);` |
| **焦点环** | `--color-ring` 用于 `outline`，在所有可交互元素上强制。| `outline: 2px solid var(--color-ring);` |
| **ARIA** | 每个交互组件必须有 `role`、`aria-label`（或 `aria-labelledby`）属性；空状态使用 `aria-live="polite"`。| `<button aria-label={t('components.button.toggle')}>` |
| **响应式** | 使用 Tailwind‑like breakpoint tokens `--breakpoint-sm`, `--breakpoint-md`, `--breakpoint-lg` 或直接在 Figma 中设置 **Constraints**。| `@media (min-width: 1024px) { … }` |
| **无死代码** | 所有组件/页面必须在原型中有连线或交互；删除未使用的占位框。| 在 Figma “Inspect” 面板里勾选 “Only export used layers”。 |

---

## Ⅶ️⃣ 完成交付检查清单（Final Checklist）

在 AI 生成完成后，请使用以下清单手动或通过脚本验证：

| ✅ 检查项 | 描述 | 通过标准 |
|----------|------|----------|
| **主题完整** | 3 主题×Light/Dark，颜色、阴影、光效均有差异 | Figma 中可切换 `Theme` Variant，观察颜色明显变化 |
| **首页结构** | Hero → Five‑High → Feature Grid → Updates → Footer | 每个区块都有实际交互（CTA、Carousel） |
| **导航栏** | Desktop、Tablet、Mobile 3 变体，键盘可达，focus ring 可见 | `Tab` → `Enter` 能打开抽屉，`aria‑expanded` 正确 |
| **组件库** | 26 组件均有真实交互预览、过滤、复制 JSX 功能 | 过滤栏能实时过滤，点击卡片出现 Toast |
| **ARIA 完整** | 所有交互元素拥有 `role`、`aria-label`、focus 样式 | `axe` 扫描 ≤ 0 警告 |
| **Token 使用** | 所有颜色、间距、圆角、阴影、动画均引用 `var(--*)` | 在 Figma “Inspect” 中仅出现 `var(--*)`，无硬编码颜色 |
| **响应式** | 三个断点（Mobile/Tablet/Desktop）均布局完整，无文字堆叠 | 手动切换画板宽度检查 |
| **无死代码** | 所有层都有连线或交互，未使用的占位框已删除 | 在 Figma “Layers” 找不到标记为 “TODO” 的图层 |
| **可访问对比度** | 所有文字/背景对比度 ≥ 4.5:1（使用 OKLCH 计算） | 通过 `axe` 报告或手动检查 |
| **性能预算** | 主题切换、语言切换无额外 JS 计算，CSS 体积 ≤ 200 KB（在项目打包后验证） | CI 中 Lighthouse CI 报告通过 |
| **文档/说明** | 每个组件卡片都有 `t('components.xxx.desc')` 文案引用，Figma 中附带 `Notes` 注释 | 阅读 `Notes` 能看到 i18n 键名 |

> 若任意项未通过，请在 Figma 中回到对应 Frame 并修改，或在 `design/tokens.json` 中补足缺失的 token。

---

## 📦 最终使用方式

1. **复制**每段 Prompt（①‑Ⅴ），粘贴到 **Figma AI**，一次生成四个文件（主题、首页、导航、组件库）。  
2. **在 Figma**确认所有 **Component Variants**、**Auto‑Layout**、**Responsive Constraints** 已创建。  
3. **导出** `design/tokens.json`（AI 会在 Prompt 中自动生成），放入项目根目录。  
4. **运行** `npm run build:tokens` → 生成 CSS/JS 变量文件。  
5. **执行** QA 检查脚本 `npm run qa`，确保所有 **五高 / 五标 / 五化** 指标通过。  
