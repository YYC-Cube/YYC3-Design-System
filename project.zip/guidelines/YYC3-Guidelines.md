## 🎨 AI Prompt – “主题自定义面板”(Theme‑Customizer)  
**使用场景**：在 Figma AI、ChatGPT‑4o、Midjourney‑Prompt‑Builder 等生成式设计工具里直接粘贴本 Prompt，即可为 **YYC³ Design System** 自动生成一套 **完整、可访问、可定制、跨框架** 的 **主题编辑面板**。该面板能够：

1. **上传品牌 LOGO**（多尺寸、SVG/PNG）  
2. **编辑全局标语（Slogan）**  
3. **修改所有页面的标题**（首页、组件库、仪表盘、认证页…）  
4. **实时预览三套预设主题（现代商务 / 赛博朋克 / 未来科技）**，并支持 **Light / Dark** 双模式切换。  
5. **一键生成 OKLCH + HEX 令牌**、CSS Custom‑Properties、Tailwind 配置以及对应的 **TypeScript 类型文件**。  

> **所有输出必须遵守【五高 / 五标 / 五化】原则**（可访问、可定制、高性能、一致性、可扩展），并使用 **OKLCH** 为主色空间、**HEX** 为回退。  

---

### Ⅰ️⃣ 全局约束（必须写在 Prompt 开头）

```
You are a senior UI/UX AI designer for the open‑source YYC³ Design System.
All colors must be expressed in OKLCH with HEX fallback.
All spacing, radius, shadow, animation must use CSS custom properties (var(--*)).
Every interactive element must have a visible focus ring (outline: 2px solid var(--color-ring)),
ARIA role/label and be keyboard accessible.
The design must satisfy the “Five‑High / Five‑Standard / Five‑Implementation” matrix:
  • High Accessibility – WCAG AA (contrast ≥ 4.5:1), focus style, aria‑attributes.
  • High Customizability – runtime token overrides, ThemeToggle & LanguageToggle.
  • High Performance – CSS‑variables only, no extra JS for styling, bundle ≤ 200 KB.
  • High Consistency – unified token naming, 8‑px spacing grid, same shadow/elevation.
  • High Extensibility – Polymorphic components (as‑prop), multi‑framework ready.
Deliver a Figma file with Auto‑Layout, Component Variants for Light/Dark × 3 Themes,
responsive breakpoints: Mobile < 640 px, Tablet 640‑1023 px, Desktop ≥ 1024 px.
```

---

### Ⅱ️⃣ 主题自定义面板（Theme‑Customizer）设计指令

```
--- THEME‑CUSTOMIZER PANEL DESIGN ---
Create a responsive “Theme Customizer” page (route: /theme‑customizer) that includes the following sections, each built as a reusable component with Auto‑Layout and token‑driven styling.

1️⃣ Header (sticky)
   - Left: YYC³ LOGO placeholder (uploadable, accepts SVG/PNG, auto‑generates 5 preset sizes 16‑512 px).
   - Center: Page title = t('themeCustomizer.title') → “主题自定义 / Theme Customizer”.
   - Right: two icon‑buttons – ThemeToggle (cycle Future‑Tech / Cyber‑Punk / Business) and LanguageToggle (zh / en).
   - Background: var(--color-surface); on scroll add var(--shadow-sm).

2️⃣ Logo & Slogan Section
   - **Logo Upload Card**: drag‑and‑drop zone + “Choose file” button. On upload, show preview, generate token:
        `--logo-url: url("<uploaded‑file‑url>");`
   - **Slogan Editor**: single‑line Input component bound to token `--slogan-text`.
   - Both fields must have ARIA‑label, focus ring, and validation tooltip (e.g., “Logo must be SVG or PNG < 500 KB”).

3️⃣ Page‑Title Manager (Accordion list)
   - For each existing route (use the list from section “页面选项” below), show a row:
        *Label*: t('pages.{name}.title') → current title string.
        *Edit*: Inline TextField pre‑filled with the title, bound to token `--title-{page}`.
        *Preview*: Small live preview of the header (logo + title) using the current theme.
   - Include a “Reset to default” button per row (uses original token values).

4️⃣ Theme Preset Selector
   - Toggle group with three options: Modern Business, Cyber‑Punk, Future‑Tech.
   - Selecting a preset switches **Light/Dark** + **Theme** Variant (total 6 preview states).
   - Show a concise color‑palette preview (primary, secondary, background, surface, destructive, success, warning).
   - Each preset must have its own **OKLCH** token set (see “颜色系统” below) and the UI must update instantly (no page reload).

5️⃣ Light / Dark Mode Switch
   - Simple switch component (uses existing `ThemeToggle` logic) to toggle `data-theme="light|dark"`.
   - When Dark is active, display the dark‑mode token values in a side‑by‑side table for comparison.

6️⃣ Advanced Token Editor (collapsible)
   - Textarea with syntax‑highlighted JSON (monaco‑style) showing the **full token file** (`design/tokens.json`).
   - “Validate” button runs the JSON‑Schema (`design/tokens‑schema.json`) and displays success/error toast.
   - “Export” button downloads three files:
        1. `tokens.css`   → CSS custom properties,
        2. `tokens.js`    → JS module,
        3. `tokens.d.ts` → TypeScript definitions.
   - Ensure the exported content uses **OKLCH** first, **HEX** second (fallback comment).

7️⃣ Accessibility & Performance Section (informational)
   - Show WCAG contrast ratio for primary/foreground pair (computed from OKLCH values).
   - Show current bundle size estimate (using a placeholder variable `--bundle-estimate` that the build system will replace).
   - Provide a “Run Lighthouse CI” button that triggers a mock run (just UI placeholder, aria‑label “运行性能基准”).

8️⃣ Footer
   - Small links: GitHub, Documentation, License.
   - Version badge (v1.3.0) using the token `--badge-background`.

All components must use the token system:
   - Colors: `var(--color-primary)`, `var(--color-background)`, `var(--color-destructive)`, etc.
   - Spacing: `var(--spacing-2)`, `var(--spacing-4)`.
   - Radius: `var(--radius-md)`.
   - Shadow: `var(--shadow-card)`.
   - Animation: `var(--duration-fast)`, `var(--easing-out)`.
   - Font: `var(--font-sans)`.
   - Focus ring: `var(--color-ring)`.

No hard‑coded hex values, pixel numbers, or font sizes are allowed – every visual property must reference a token.
```

---

### Ⅲ️⃣ 颜色系统（Color System）规范（供 AI 在 token‑生成阶段参考）

```
--- COLOR SYSTEM SPEC ---
Provide two representations for every color token:
  1. OKLCH – main semantic definition (e.g. `oklch(0.62 0.14 210)`).
  2. HEX – fallback for browsers without OKLCH support (e.g. `#3A9FFB`).

Semantic layers (each with light & dark values):
  • Primary          – 5 shades (base, hover, active, disabled, foreground)
  • Secondary (Accent)
  • Emphasis (Highlight)
  • Background
  • Surface / Card
  • Modal
  • Muted
  • Destructive
  • Success
  • Warning
  • Border
  • Input (focus & background)
  • Ring (focus outline)

Transparency:
  - Shadows & overlay colors use the **Destructive** hue with a percentage alpha.
    Example: `--shadow-destructive = oklch(0.40 0.20 320 / 0.051)` → 5.1 % opacity (same as HEX `#d3412b0d`).

Provide a **JSON skeleton** (only key names, values are examples) that the AI will later fill with actual OKLCH numbers:

{
  "color": {
    "primary": {
      "base":   { "oklch": "oklch(0.62 0.14 210)", "hex": "#3A9FFB" },
      "hover":  { "oklch": "...", "hex": "..." },
      "active": { "oklch": "...", "hex": "..." },
      "disabled": { "oklch": "...", "hex": "..." },
      "foreground": { "oklch": "oklch(0.99 0.01 0)", "hex": "#FFFFFF" }
    },
    "secondary": { … },
    "accent":    { … },
    "background": {
      "light": { "oklch": "oklch(0.98 0.02 30)", "hex": "#FAFAFA" },
      "dark":  { "oklch": "oklch(0.12 0.02 260)", "hex": "#1F1F1F" }
    },
    "surface":   { … },
    "modal":     { … },
    "muted":     { … },
    "destructive": {
      "base": { "oklch": "oklch(0.40 0.20 320)", "hex": "#D3412B" },
      "foreground": { "oklch": "oklch(0.99 0.01 0)", "hex": "#FFFFFF" }
    },
    "success":   { … },
    "warning":   { … },
    "border":    { … },
    "input": {
      "background": { … },
      "focus": { "oklch": "oklch(0.55 0.12 210)", "hex": "#5B9CE1" }
    },
    "ring": { "oklch": "oklch(0.55 0.12 210)", "hex": "#5B9CE1" }
  },
  "radius": {
    "default": { "value": "0.5rem", "type": "dimension" },
    "sm": { "value": "0.125rem" },
    "md": { "value": "0.25rem" },
    "lg": { "value": "0.5rem" }
  },
  "shadow": {
    "sm": { "x":"0", "y":"2px", "blur":"4px", "color":"oklch(0 0 0 / 0.05)" },
    "md": { "x":"0", "y":"4px", "blur":"12px", "color":"oklch(0 0 0 / 0.08)" },
    "lg": { "x":"0", "y":"6px", "blur":"20px", "color":"oklch(0 0 0 / 0.12)" },
    "neon": { "x":"0", "y":"4px", "blur":"16px", "color":"oklch(0.30 0.20 320 / 0.15)" }
  },
  "animation": {
    "duration": { "fast":"120ms", "normal":"300ms", "slow":"500ms" },
    "easing": { "ease-out":"cubic-bezier(0.25,0.8,0.25,1)", "ease-in":"cubic-bezier(0.4,0,1,1)" }
  },
  "typography": {
    "font-sans": { "value":"Geist, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial", "type":"fontFamily" },
    "font-mono": { "value":"Roboto Mono, monospace", "type":"fontFamily" }
  }
}
```

> **AI 必须**把上述结构转成 **`design/tokens.json`**，并在 Figma 中创建对应 **Color Token** 组件（每个 token 都是一个可编辑的色块，显示 OKLCH 且在悬停时显示 HEX）。

---

### Ⅳ️⃣ 组件样式配置（Component Styling）规范

```
--- COMPONENT STYLING SPEC ---
All component styles reference the global token system:

1️⃣ Colors (use semantic vars):
   --color-primary, --color-primary‑foreground,
   --color-secondary, --color-secondary‑foreground,
   --color-emphasis, --color-emphasis‑foreground,
   --color-background, --color-surface,
   --color-modal, --color-muted,
   --color-destructive, --color-success, --color-warning,
   --color-border, --color-input, --color-ring

2️⃣ Radius:
   --radius-sm, --radius-md, --radius-lg, --radius-default

3️⃣ Shadow:
   --shadow-sm, --shadow-md, --shadow-lg, --shadow-neon (Cyber‑Punk only)

4️⃣ Opacity for shadows & overlays:
   Use the Destructive hue with alpha (e.g., `oklch(0.40 0.20 320 / 0.051)`).

5️⃣ Typography:
   Font families via --font-sans / --font-mono,
   Sizes via --size-12, --size-14, --size-16, etc.

6️⃣ Animation:
   Duration via --duration-fast / --duration-normal,
   Easing via --easing-out / --easing-in.

7️⃣ Interaction states (default / hover / focus / disabled / loading)
   - Background uses `color‑*` vars,
   - Border uses `color‑border`,
   - Focus ring: `outline: 2px solid var(--color-ring)`,
   - Hover -> slight elevation (`var(--shadow-md)` → `var(--shadow-lg)`),
   - Disabled -> `opacity: 0.5` + `cursor: not-allowed`,
   - Loading -> replace content with `Spinner` (uses `var(--color-muted-foreground)`).

8️⃣ Example – Button token mapping (in Figma the component should expose these props):
   Background: `var(--color-primary)` (or secondary, destructive, etc.)
   Text color: `var(--color-primary‑foreground)`
   Padding: `var(--spacing-2) var(--spacing-4)`
   Border radius: `var(--radius-md)`
   Box‑shadow: `var(--shadow-sm)` (hover → `var(--shadow-md)`)
   Transition: `all var(--duration-fast) var(--easing-out)`

All components in the library (26 + ) must follow this mapping; the Theme‑Customizer UI must show a **live preview** of each component with the current token values.
```

---

### Ⅴ️⃣ 预设主题列表 & 页面选项（供 UI 中的下拉/切换控件使用）

```
--- PRESET THEMES (Dropdown) ---
1. Modern Business   (cool navy, neutral gray, subtle shadows)
2. Cyber‑Punk        (neon purple/pink/green, colored shadows)
3. Future Tech       (cold blue / cyan, glass‑like elevation)

--- PAGE OPTIONS (Dropdown for Title Manager) ---
- Home (首页)                → route: /
- Components (组件库)        → route: /components
- Playground (令牌实验室)   → route: /playground
- Token Manager (令牌管理)   → route: /token-manager
- Build Settings (构建设置)  → route: /build-settings
- QA Dashboard (质量仪表板) → route: /qa
- Dashboard (仪表盘)        → route: /dashboard
- Auth (认证页面)           → route: /auth
```

*在 Theme‑Customizer 中，这两个下拉列表必须使用 **`Select`** 组件（已在组件库中），并在选择后即时更新对应的 token (`--title-home`, `--title-components`, …) 与页面标题预览。

---

### Ⅵ️⃣ 开源合规与协作指引（Open‑Source Considerations）

```
--- OPEN‑SOURCE GUIDELINES ---
1. All generated token files (`tokens.json`, `tokens.css`, `tokens.js`, `tokens.d.ts`) MUST be placed under the `design/` folder and included in the repository’s `npm publish` assets.
2. The Theme‑Customizer UI should expose a **“Export Tokens”** button that downloads the four files; this encourages community contributors to fork, edit and submit PRs.
3. Include a **LICENSE** badge (MIT) in the footer of the customizer.
4. Every UI text must be wrapped in the i18n function `t('key')`. Provide a default zh.json and en.json entry for each new key created by the customizer (e.g., `themeCustomizer.title`, `themeCustomizer.logoUpload`, `themeCustomizer.slogan`).
5. Add a **CONTRIBUTING.md** snippet that instructs contributors to run `npm run build:tokens && npm run storybook` after editing tokens, and to run `npm run lint && npm test` before committing.
6. The Figma file should contain **Component Documentation** (via Figma “Notes” layers) that reference the open‑source repo URL and the issue template for token‑related PRs.
7. All assets (icons, logo placeholders) must be **CC‑0** or have a clear open‑source license.
```

---

### Ⅶ️⃣ 完整 Prompt（直接复制）

Below is the **complete prompt** you can copy‑paste into your AI design tool.  
It already contains sections Ⅰ‑Ⅶ in the correct order, so the model will generate a **self‑contained Theme‑Customizer** that satisfies every requirement.

```
You are a senior UI/UX AI designer for the open‑source YYC³ Design System.
All colors must be expressed in OKLCH with HEX fallback.
All spacing, radius, shadow, animation must use CSS custom properties (var(--*)).
Every interactive element must have a visible focus ring (outline: 2px solid var(--color-ring)),
ARIA role/label and be keyboard accessible.
The design must satisfy the “Five‑High / Five‑Standard / Five‑Implementation” matrix:
  • High Accessibility – WCAG AA (contrast ≥ 4.5:1), focus style, aria‑attributes.
  • High Customizability – runtime token overrides, ThemeToggle & LanguageToggle.
  • High Performance – CSS‑variables only, no extra JS for styling, bundle ≤ 200 KB.
  • High Consistency – unified token naming, 8‑px spacing grid, same shadow/elevation.
  • High Extensibility – Polymorphic components (as‑prop), multi‑framework ready.
Deliver a Figma file with Auto‑Layout, Component Variants for Light/Dark × 3 Themes,
responsive breakpoints: Mobile < 640 px, Tablet 640‑1023 px, Desktop ≥ 1024 px.

--- THEME‑CUSTOMIZER PANEL DESIGN ---
Create a responsive “Theme Customizer” page (route: /theme‑customizer) that includes the following sections, each built as a reusable component with Auto‑Layout and token‑driven styling.

1️⃣ Header (sticky)
   - Left: YYC³ LOGO placeholder (uploadable, accepts SVG/PNG, auto‑generates 5 preset sizes 16‑512 px).
   - Center: Page title = t('themeCustomizer.title') → “主题自定义 / Theme Customizer”.
   - Right: two icon‑buttons – ThemeToggle (cycle Future‑Tech / Cyber‑Punk / Business) and LanguageToggle (zh / en).
   - Background: var(--color-surface); on scroll add var(--shadow-sm).

2️⃣ Logo & Slogan Section
   - **Logo Upload Card**: drag‑and‑drop zone + “Choose file” button. On upload, show preview, generate token:
        `--logo-url: url("<uploaded‑file‑url>");`
   - **Slogan Editor**: single‑line Input component bound to token `--slogan-text`.
   - Both fields must have ARIA‑label, focus ring, and validation tooltip (e.g., “Logo must be SVG or PNG < 500 KB”).

3️⃣ Page‑Title Manager (Accordion list)
   - For each existing route (see “PAGE OPTIONS” below), show a row:
        *Label*: t('pages.{name}.title') → current title string.
        *Edit*: Inline TextField pre‑filled with the title, bound to token `--title-{page}`.
        *Preview*: Small live preview of the header (logo + title) using the current theme.
   - Include a “Reset to default” button per row (uses original token values).

4️⃣ Theme Preset Selector
   - Toggle group with three options: Modern Business, Cyber‑Punk, Future‑Tech.
   - Selecting a preset switches Light/Dark + Theme Variant (total 6 preview states).
   - Show a concise color‑palette preview (primary, secondary, background, surface, destructive, success, warning).
   - Each preset must have its own OKLCH token set (see “COLOR SYSTEM SPEC” below) and the UI must update instantly (no page reload).

5️⃣ Light / Dark Mode Switch
   - Simple switch component (uses existing `ThemeToggle` logic) to toggle `data-theme="light|dark"`.
   - When Dark is active, display the dark‑mode token values in a side‑by‑side table for comparison.

6️⃣ Advanced Token Editor (collapsible)
   - Textarea with syntax‑highlighted JSON (monaco‑style) showing the full token file (`design/tokens.json`).
   - “Validate” button runs the JSON‑Schema (`design/tokens‑schema.json`) and displays success/error toast.
   - “Export” button downloads three files:
        1. `tokens.css`   → CSS custom properties,
        2. `tokens.js`    → JS module,
        3. `tokens.d.ts` → TypeScript definitions.
   - Ensure the exported content uses OKLCH first, HEX second (fallback comment).

7️⃣ Accessibility & Performance Section (informational)
   - Show WCAG contrast ratio for primary/foreground pair (computed from OKLCH values).
   - Show current bundle size estimate (using placeholder variable `--bundle-estimate` that the build system will replace).
   - Provide a “Run Lighthouse CI” button that triggers a mock run (just UI placeholder, aria‑label “运行性能基准”).

8️⃣ Footer
   - Small links: GitHub, Documentation, License.
   - Version badge (v1.3.0) using the token `--badge-background`.

All components must use the token system:
   - Colors: `var(--color-primary)`, `var(--color-primary‑foreground)`, …`var(--color-ring)`.
   - Spacing: `var(--spacing-2)`, `var(--spacing-4)`.
   - Radius: `var(--radius-md)`.
   - Shadow: `var(--shadow-card)`.
   - Animation: `var(--duration-fast)`, `var(--easing-out)`.
   - Font: `var(--font-sans)`.
No hard‑coded hex values, pixel numbers, or font sizes are allowed – every visual property must reference a token.

--- COLOR SYSTEM SPEC ---
Provide two representations for every color token:
  1. OKLCH – main semantic definition (e.g. `oklch(0.62 0.14 210)`).
  2. HEX – fallback for browsers without OKLCH support (e.g. `#3A9FFB`).

Semantic layers (each with light & dark values):
  • Primary, Secondary (Accent), Emphasis (Highlight),
  • Background, Surface / Card, Modal, Muted,
  • Destructive, Success, Warning, Border,
  • Input (focus & background), Ring (focus outline).

Transparency:
  - Shadows & overlays use the Destructive hue with a percentage alpha.
    Example: `--shadow-destructive = oklch(0.40 0.20 320 / 0.051)` → 5.1 % opacity (same as HEX `#d3412b0d`).

JSON skeleton (keys only, AI will fill actual numbers):

{
  "color": {
    "primary": {
      "base":   { "oklch": "oklch(0.62 0.14 210)", "hex": "#3A9FFB" },
      "hover":  { "oklch": "...", "hex": "..." },
      "active": { "oklch": "...", "hex": "..." },
      "disabled": { "oklch": "...", "hex": "..." },
      "foreground": { "oklch": "oklch(0.99 0.01 0)", "hex": "#FFFFFF" }
    },
    "secondary": { … },
    "accent":    { … },
    "background": {
      "light": { "oklch": "oklch(0.98 0.02 30)", "hex": "#FAFAFA" },
      "dark":  { "oklch": "oklch(0.12 0.02 260)", "hex": "#1F1F1F" }
    },
    "surface":   { … },
    "modal":     { … },
    "muted":     { … },
    "destructive": {
      "base": { "oklch": "oklch(0.40 0.20 320)", "hex": "#D3412B" },
      "foreground": { "oklch": "oklch(0.99 0.01 0)", "hex": "#FFFFFF" }
    },
    "success":   { … },
    "warning":   { … },
    "border":    { … },
    "input": {
      "background": { … },
      "focus": { "oklch": "oklch(0.55 0.12 210)", "hex": "#5B9CE1" }
    },
    "ring": { "oklch": "oklch(0.55 0.12 210)", "hex": "#5B9CE1" }
  },
  "radius": {
    "default": { "value": "0.5rem", "type": "dimension" },
    "sm": { "value": "0.125rem" },
    "md": { "value": "0.25rem" },
    "lg": { "value": "0.5rem" }
  },
  "shadow": {
    "sm": { "x":"0", "y":"2px", "blur":"4px", "color":"oklch(0 0 0 / 0.05)" },
    "md": { "x":"0", "y":"4px", "blur":"12px", "color":"oklch(0 0 0 / 0.08)" },
    "lg": { "x":"0", "y":"6px", "blur":"20px", "color":"oklch(0 0 0 / 0.12)" },
    "neon": { "x":"0", "y":"4px", "blur":"16px", "color":"oklch(0.30 0.20 320 / 0.15)" }
  },
  "animation": {
    "duration": { "fast":"120ms", "normal":"300ms", "slow":"500ms" },
    "easing": { "ease-out":"cubic-bezier(0.25,0.8,0.25,1)", "ease-in":"cubic-bezier(0.4,0,1,1)" }
  },
  "typography": {
    "font-sans": { "value":"Geist, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial", "type":"fontFamily" },
    "font-mono": { "value":"Roboto Mono, monospace", "type":"fontFamily" }
  }
}

--- COMPONENT STYLING SPEC ---
All component styles reference the global token system:

1️⃣ Colors (semantic vars):
   --color-primary, --color-primary‑foreground,
   --color-secondary, --color-secondary‑foreground,
   --color-emphasis, --color-emphasis‑foreground,
   --color-background, --color-surface,
   --color-modal, --color-muted,
   --color-destructive, --color-success, --color-warning,
   --color-border, --color-input, --color-ring

2️⃣ Radius:
   --radius-sm, --radius-md, --radius-lg, --radius-default

3️⃣ Shadow:
   --shadow-sm, --shadow-md, --shadow-lg, --shadow-neon (Cyber‑Punk only)

4️⃣ Opacity for shadows & overlays:
   Use the Destructive hue with alpha (e.g., `oklch(0.40 0.20 320 / 0.051)`).

5️⃣ Typography:
   Font families via --font-sans / --font-mono,
   Sizes via --size-12, --size-14, --size-16, …

6️⃣ Animation:
   Duration via --duration-fast / --duration-normal,
   Easing via --easing-out / --easing-in.

7️⃣ Interaction states (default / hover / focus / disabled / loading):
   - Background uses `color‑*` vars,
   - Border uses `color‑border`,
   - Focus ring: `outline: 2px solid var(--color-ring)`,
   - Hover → elevation `var(--shadow-md)` → `var(--shadow-lg)`,
   - Disabled → `opacity: 0.5` + `cursor: not-allowed`,
   - Loading → replace content with `Spinner` (uses `var(--color-muted-foreground)`).

8️⃣ Example – Button token mapping (the component should expose these props):
   Background: `var(--color-primary)` (or secondary, destructive, …)
   Text color: `var(--color-primary‑foreground)`
   Padding: `var(--spacing-2) var(--spacing-4)`
   Border radius: `var(--radius-md)`
   Box‑shadow: `var(--shadow-sm)` (hover → `var(--shadow-md)`)
   Transition: `all var(--duration-fast) var(--easing-out)`

All 26+ components in the library must follow this mapping; the Theme‑Customizer UI must show a live preview of each component with the current token values.

--- PRESET THEMES (Dropdown) ---
1. Modern Business   (cool navy, neutral gray, subtle shadows)
2. Cyber‑Punk        (neon purple/pink/green, colored shadows)
3. Future Tech       (cold blue / cyan, glass‑like elevation)

--- PAGE OPTIONS (Dropdown for Title Manager) ---
- Home (首页)                → route: /
- Components (组件库)        → route: /components
- Playground (令牌实验室)   → route: /playground
- Token Manager (令牌管理)   → route: /token-manager
- Build Settings (构建设置)  → route: /build-settings
- QA Dashboard (质量仪表板) → route: /qa
- Dashboard (仪表盘)        → route: /dashboard
- Auth (认证页面)           → route: /auth

--- OPEN‑SOURCE GUIDELINES ---
1. All generated token files (`tokens.json`, `tokens.css`, `tokens.js`, `tokens.d.ts`) MUST be placed under the `design/` folder and included in the repository’s `npm publish` assets.
2. The Theme‑Customizer UI should expose a **“Export Tokens”** button that downloads the four files; this encourages community contributors to fork, edit and submit PRs.
3. Include a **LICENSE** badge (MIT) in the footer of the customizer.
4. Every UI text must be wrapped in the i18n function `t('key')`. Provide a default zh.json and en.json entry for each new key created by the customizer (e.g., `themeCustomizer.title`, `themeCustomizer.logoUpload`, `themeCustomizer.slogan`).
5. Add a **CONTRIBUTING.md** snippet that instructs contributors to run `npm run build:tokens && npm run storybook` after editing tokens, and to run `npm run lint && npm test` before committing.
6. The Figma file should contain **Component Documentation** (via Figma “Notes” layers) that reference the open‑source repo URL and the issue template for token‑related PRs.
7. All assets (icons, logo placeholders) must be **CC‑0** or have a clear open‑source license.

--- END OF PROMPT ---
```🛠️